import React, { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';

interface BarChartProps {
  data: {
    labels: string[];
    datasets: {
      label: string;
      data: number[];
      backgroundColor?: string;
      borderColor?: string;
      borderWidth?: number;
    }[];
  };
  height?: number;
  className?: string;
}

const BarChart: React.FC<BarChartProps> = ({ data, height = 300, className = '' }) => {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);

  useEffect(() => {
    if (chartRef.current) {
      // Destroy existing chart if it exists
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }

      const ctx = chartRef.current.getContext('2d');
      
      if (ctx) {
        // Apply custom styling to the datasets
        const styledDatasets = data.datasets.map((dataset, index) => ({
          ...dataset,
          backgroundColor: dataset.backgroundColor || '#FF5D2B',
          borderColor: dataset.borderColor || '#FF5D2B',
          borderWidth: dataset.borderWidth || 0,
          borderRadius: 4,
        }));

        // Create the chart
        chartInstance.current = new Chart(ctx, {
          type: 'bar',
          data: {
            ...data,
            datasets: styledDatasets,
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                display: true,
                position: 'top',
                labels: {
                  color: '#d1d5db', // gray-300
                  font: {
                    size: 12,
                  },
                },
              },
              tooltip: {
                backgroundColor: '#374151', // gray-700
                titleColor: '#f3f4f6', // gray-100
                bodyColor: '#e5e7eb', // gray-200
                borderColor: '#4b5563', // gray-600
                borderWidth: 1,
                padding: 10,
                cornerRadius: 4,
                displayColors: true,
              },
            },
            scales: {
              x: {
                grid: {
                  color: 'rgba(75, 85, 99, 0.2)', // gray-600 with opacity
                },
                ticks: {
                  color: '#9ca3af', // gray-400
                },
              },
              y: {
                beginAtZero: true,
                grid: {
                  color: 'rgba(75, 85, 99, 0.2)', // gray-600 with opacity
                },
                ticks: {
                  color: '#9ca3af', // gray-400
                },
              },
            },
            animation: {
              duration: 1500,
              easing: 'easeOutQuart',
            },
          },
        });
      }
    }

    // Cleanup function
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
        chartInstance.current = null;
      }
    };
  }, [data]);

  return (
    <div className={`w-full ${className}`} style={{ height }}>
      <canvas ref={chartRef}></canvas>
    </div>
  );
};

export default BarChart;