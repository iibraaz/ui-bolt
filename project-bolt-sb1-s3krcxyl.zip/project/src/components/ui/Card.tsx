import React from 'react';

interface CardProps {
  title?: string;
  subtitle?: string;
  icon?: React.ReactNode;
  headerAction?: React.ReactNode;
  footer?: React.ReactNode;
  className?: string;
  contentClassName?: string;
  children: React.ReactNode;
  hoverable?: boolean;
  glow?: boolean;
}

const Card: React.FC<CardProps> = ({
  title,
  subtitle,
  icon,
  headerAction,
  footer,
  className = '',
  contentClassName = '',
  children,
  hoverable = false,
  glow = false,
}) => {
  return (
    <div 
      className={`
        bg-[#171717] border border-[#F2F2F2] rounded-lg overflow-hidden
        ${hoverable ? 'transition-transform duration-300 hover:-translate-y-1 hover:shadow-lg' : ''}
        ${glow ? 'shadow-[0_0_15px_rgba(255,93,43,0.15)]' : 'shadow-md'}
        ${className}
      `}
    >
      {(title || icon || headerAction) && (
        <div className="flex items-center justify-between border-b border-[#F2F2F2] px-4 py-3">
          <div className="flex items-center space-x-3">
            {icon && <div className="text-[#FF5D2B]">{icon}</div>}
            <div>
              {title && <h3 className="font-medium text-white">{title}</h3>}
              {subtitle && <p className="text-sm text-gray-400">{subtitle}</p>}
            </div>
          </div>
          {headerAction && <div>{headerAction}</div>}
        </div>
      )}
      
      <div className={`p-4 ${contentClassName}`}>
        {children}
      </div>
      
      {footer && (
        <div className="border-t border-[#F2F2F2] px-4 py-3 bg-[#171717]">
          {footer}
        </div>
      )}
    </div>
  );
};

export default Card;