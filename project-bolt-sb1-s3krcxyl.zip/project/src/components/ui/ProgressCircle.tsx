import React from 'react';

interface ProgressCircleProps {
  value: number; // 0-100
  size?: number;
  strokeWidth?: number;
  color?: string;
  bgColor?: string;
  showLabel?: boolean;
  labelFontSize?: number;
  className?: string;
}

const ProgressCircle: React.FC<ProgressCircleProps> = ({
  value,
  size = 100,
  strokeWidth = 8,
  color = '#FF5D2B',
  bgColor = '#fafafa',
  showLabel = true,
  labelFontSize = 20,
  className = '',
}) => {
  // Ensure value is between 0-100
  const safeValue = Math.min(100, Math.max(0, value));
  
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const strokeDashoffset = circumference - (safeValue / 100) * circumference;
  
  return (
    <div className={`relative inline-flex items-center justify-center ${className}`} style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="transform -rotate-90">
        {/* Background circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="transparent"
          stroke={bgColor}
          strokeWidth={strokeWidth}
          strokeOpacity={0.1}
        />
        
        {/* Progress circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="transparent"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          className="transition-all duration-1000 ease-out"
        />
      </svg>
      
      {showLabel && (
        <div 
          className="absolute inset-0 flex items-center justify-center text-white font-medium"
          style={{ fontSize: labelFontSize }}
        >
          {Math.round(safeValue)}%
        </div>
      )}
    </div>
  );
};

export default ProgressCircle;