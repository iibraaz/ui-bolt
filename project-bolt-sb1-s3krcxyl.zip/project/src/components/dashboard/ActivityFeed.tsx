import React, { useEffect, useState } from 'react';
import Card from '../ui/Card';
import Badge from '../ui/Badge';
import { MessageSquare, Clock, RefreshCw, Wifi, WifiOff } from 'lucide-react';
import { supabase, subscribeToTelegramUpdates } from '../../lib/supabase';

interface TelegramUpdate {
  id: string;
  message_id: string;
  chat_id: string;
  from_id: string;
  from_name: string;
  content: string;
  category: 'progress' | 'issue' | 'need';
  created_at: string;
}

const ActivityFeed: React.FC = () => {
  const [updates, setUpdates] = useState<TelegramUpdate[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [realtimeConnected, setRealtimeConnected] = useState(false);

  const fetchUpdates = async () => {
    try {
      console.log('🔄 Fetching telegram updates from ActivityFeed...');
      
      const { data, error } = await supabase
        .from('telegram_updates')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(20);

      console.log('📊 Query result:', { data, error });

      if (error) {
        console.error('❌ Supabase error:', error);
        throw error;
      }
      
      console.log('✅ Fetched updates:', data?.length || 0, 'items');
      setUpdates(data || []);
      setError(null);
    } catch (err) {
      console.error('❌ Error fetching updates:', err);
      setError(`Failed to load updates: ${err instanceof Error ? err.message : 'Unknown error'}`);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchUpdates();
    setRefreshing(false);
  };

  useEffect(() => {
    console.log('🚀 Setting up ActivityFeed component...');
    
    const loadUpdates = async () => {
      setLoading(true);
      await fetchUpdates();
      setLoading(false);
    };

    // Load initial data
    loadUpdates();

    // Subscribe to real-time updates using global subscription
    const unsubscribe = subscribeToTelegramUpdates((payload) => {
      console.log('🔥 Real-time update received in ActivityFeed:', payload);
      setRealtimeConnected(true);
      
      if (payload.eventType === 'INSERT') {
        const newUpdate = payload.new as TelegramUpdate;
        setUpdates(prev => {
          // Check if update already exists to prevent duplicates
          const exists = prev.some(update => update.id === newUpdate.id);
          if (exists) {
            console.log('⚠️ Duplicate update detected, skipping');
            return prev;
          }
          console.log('✅ Adding new update to activity feed');
          return [newUpdate, ...prev.slice(0, 19)]; // Keep only 20 most recent
        });
      } else if (payload.eventType === 'DELETE') {
        const deletedUpdate = payload.old as TelegramUpdate;
        console.log('🗑️ Removing deleted update from activity feed');
        setUpdates(prev => prev.filter(update => update.id !== deletedUpdate.id));
      } else if (payload.eventType === 'UPDATE') {
        const updatedUpdate = payload.new as TelegramUpdate;
        console.log('📝 Updating existing update in activity feed');
        setUpdates(prev => prev.map(update => 
          update.id === updatedUpdate.id ? updatedUpdate : update
        ));
      }
    });

    // Auto-refresh every 60 seconds as fallback
    const autoRefresh = setInterval(() => {
      if (!realtimeConnected) {
        console.log('🔄 Real-time not connected, auto-refreshing activity feed...');
        fetchUpdates();
      }
    }, 60000);

    // Cleanup function
    return () => {
      console.log('🧹 Cleaning up ActivityFeed subscriptions...');
      unsubscribe();
      clearInterval(autoRefresh);
    };
  }, []); // Empty dependency array to run only once

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });
  };

  const getBadgeVariant = (category: string): 'success' | 'warning' | 'error' => {
    switch (category) {
      case 'progress':
        return 'success';
      case 'issue':
        return 'error';
      case 'need':
        return 'warning';
      default:
        return 'success';
    }
  };

  const getCategoryLabel = (category: string): string => {
    switch (category) {
      case 'progress':
        return 'Progress';
      case 'issue':
        return 'Issue';
      case 'need':
        return 'Need';
      default:
        return 'Update';
    }
  };

  if (loading) {
    return (
      <Card 
        title="Engineer Updates" 
        icon={<MessageSquare size={18} />}
        className="h-full"
        headerAction={
          <div className="flex items-center space-x-2">
            <WifiOff size={14} className="text-gray-400" />
            <button
              disabled
              className="p-1 text-gray-400"
            >
              <RefreshCw size={16} />
            </button>
          </div>
        }
      >
        <div className="flex items-center justify-center h-32">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#FF5D2B]"></div>
        </div>
      </Card>
    );
  }

  return (
    <Card 
      title="Engineer Updates" 
      icon={<MessageSquare size={18} />}
      className="h-full"
      contentClassName="p-0"
      headerAction={
        <div className="flex items-center space-x-2">
          {realtimeConnected ? (
            <Wifi size={14} className="text-green-400" />
          ) : (
            <WifiOff size={14} className="text-red-400" />
          )}
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="p-1 text-gray-400 hover:text-white transition-colors"
            title="Refresh updates"
          >
            <RefreshCw size={16} className={refreshing ? 'animate-spin' : ''} />
          </button>
        </div>
      }
    >
      <div className="divide-y divide-gray-700">
        {error && (
          <div className="p-4 text-center">
            <p className="text-red-500 mb-2">{error}</p>
            <button 
              onClick={handleRefresh}
              className="text-sm text-[#FF5D2B] hover:text-[#FF7A50]"
            >
              Try again
            </button>
          </div>
        )}
        
        {updates.length === 0 && !error ? (
          <div className="p-4 text-center text-gray-500">
            <MessageSquare size={48} className="mx-auto mb-2 opacity-50" />
            <p>No updates from engineers yet</p>
            <p className="text-xs mt-1">Messages sent to your Telegram bot will appear here</p>
            <button 
              onClick={handleRefresh}
              className="mt-2 text-sm text-[#FF5D2B] hover:text-[#FF7A50]"
            >
              Refresh
            </button>
          </div>
        ) : (
          updates.map((update) => (
            <div key={update.id} className="p-4 hover:bg-gray-800/50 transition-colors">
              <div className="flex items-start space-x-3">
                <div className="flex-shrink-0">
                  <div className="w-10 h-10 rounded-full overflow-hidden bg-[#FF5D2B]/20">
                    <div className="w-full h-full flex items-center justify-center text-[#FF5D2B]">
                      {update.from_name.charAt(0).toUpperCase()}
                    </div>
                  </div>
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-white truncate">
                      {update.from_name}
                    </p>
                    <Badge variant={getBadgeVariant(update.category)}>
                      {getCategoryLabel(update.category)}
                    </Badge>
                  </div>
                  
                  <p className="mt-1 text-sm text-gray-300">
                    {update.content}
                  </p>
                  
                  <div className="mt-2 flex items-center text-xs text-gray-500">
                    <Clock size={12} className="mr-1" />
                    <span>{formatDate(update.created_at)}</span>
                    <span className="mx-1">•</span>
                    <span>{formatTime(update.created_at)}</span>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </Card>
  );
};

export default ActivityFeed;