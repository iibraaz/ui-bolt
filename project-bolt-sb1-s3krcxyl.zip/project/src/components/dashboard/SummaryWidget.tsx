import React from 'react';
import Card from '../ui/Card';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface SummaryWidgetProps {
  title: string;
  value: number | string;
  icon: React.ReactNode;
  description?: string;
  change?: {
    value: number;
    positive: boolean;
  };
  color?: string;
}

const SummaryWidget: React.FC<SummaryWidgetProps> = ({
  title,
  value,
  icon,
  description,
  change,
  color = '#FF5D2B',
}) => {
  return (
    <Card hoverable className="h-full">
      <div className="flex items-start">
        <div className={`p-2 rounded-md mr-4`} style={{ backgroundColor: `${color}20` }}>
          <div style={{ color }}>{icon}</div>
        </div>
        
        <div>
          <h3 className="text-sm font-medium text-gray-400">{title}</h3>
          <div className="mt-1 flex items-baseline">
            <p className="text-2xl font-semibold text-white">{value}</p>
            
            {change && (
              <span className={`ml-2 text-xs font-medium ${change.positive ? 'text-green-400' : 'text-red-400'}`}>
                {change.positive ? '+' : ''}{change.value}%
              </span>
            )}
          </div>
          
          {description && (
            <p className="mt-1 text-xs text-gray-500">{description}</p>
          )}
        </div>
      </div>
    </Card>
  );
};

export default SummaryWidget;