import React, { useState } from 'react';
import { Send } from 'lucide-react';
import { useMessageStore } from '../../store/messageStore';
import Button from '../ui/Button';

interface MessageInputProps {
  userId: string;
}

const MessageInput: React.FC<MessageInputProps> = ({ userId }) => {
  const [message, setMessage] = useState('');
  const { sendMessage } = useMessageStore();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    try {
      await sendMessage(message, userId);
      setMessage('');
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 border-t border-gray-700">
      <div className="flex space-x-2">
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Type your message..."
          className="flex-1 bg-[#171717] border border-gray-700 rounded-md py-2 px-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#FF5D2B]/50 focus:border-transparent"
        />
        <Button
          type="submit"
          variant="primary"
          icon={<Send size={16} />}
          disabled={!message.trim()}
        >
          Send
        </Button>
      </div>
    </form>
  );
};

export default MessageInput;