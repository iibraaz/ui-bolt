import React, { useEffect, useRef } from 'react';
import { useMessageStore } from '../../store/messageStore';
import { mockUsers } from '../../utils/mockData';
import { MessageCircle } from 'lucide-react';

const MessageList = () => {
  const { messages, loading, error } = useMessageStore();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-red-500 p-4">
        <span className="text-lg font-semibold">Error loading messages</span>
        <span className="text-sm">{error}</span>
      </div>
    );
  }

  if (!messages.length) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-gray-500 p-4">
        <MessageCircle className="w-12 h-12 mb-2" />
        <span className="text-lg font-semibold">No messages yet</span>
        <span className="text-sm">Start a conversation!</span>
      </div>
    );
  }

  return (
    <div className="flex flex-col space-y-4 p-4 overflow-y-auto h-full">
      {messages.map((message) => {
        const sender = mockUsers.find(user => user.id === message.sender_id);
        return (
          <div
            key={message.id}
            className={`flex items-start space-x-2 ${
              message.sender_id === 'current-user' ? 'flex-row-reverse space-x-reverse' : ''
            }`}
          >
            <div className="w-8 h-8 rounded-full bg-gray-200 overflow-hidden flex-shrink-0">
              {sender?.avatar && (
                <img
                  src={sender.avatar}
                  alt={sender.name}
                  className="w-full h-full object-cover"
                />
              )}
            </div>
            <div
              className={`flex flex-col max-w-[70%] ${
                message.sender_id === 'current-user'
                  ? 'items-end'
                  : 'items-start'
              }`}
            >
              <span className="text-xs text-gray-500 mb-1">
                {sender?.name || 'Unknown User'}
              </span>
              <div
                className={`rounded-lg p-3 ${
                  message.sender_id === 'current-user'
                    ? 'bg-primary text-white'
                    : 'bg-gray-100'
                }`}
              >
                <p className="text-sm">{message.content}</p>
              </div>
              <span className="text-xs text-gray-400 mt-1">
                {new Date(message.timestamp).toLocaleTimeString()}
              </span>
            </div>
          </div>
        );
      })}
      <div ref={messagesEndRef} />
    </div>
  );
};

export default MessageList;