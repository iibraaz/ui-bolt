// Type definitions for the EVRLS application

export interface User {
  id: string;
  name: string;
  role: 'owner' | 'engineer';
  avatar?: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  progress: number; // 0-100
  startDate: string;
  endDate: string;
  phases: Phase[];
}

export interface Phase {
  id: string;
  projectId: string;
  name: string;
  description: string;
  progress: number; // 0-100
  startDate: string;
  endDate: string;
  tasks: Task[];
}

export interface Task {
  id: string;
  phaseId: string;
  title: string;
  description: string;
  assignee: string;
  status: 'todo' | 'in-progress' | 'completed';
  dueDate: string;
  priority: 'low' | 'medium' | 'high';
}

export interface Update {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  timestamp: string;
  content: string;
  category: 'progress' | 'issue' | 'need';
  projectId: string;
  phaseId?: string;
}

export interface Message {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  recipientId: string;
  recipientName: string;
  content: string;
  timestamp: string;
  isTask: boolean;
  taskStatus?: 'todo' | 'in-progress' | 'completed';
}

export interface FileItem {
  id: string;
  name: string;
  uploadedBy: string;
  uploadDate: string;
  size: number;
  type: string;
  url: string;
  aiSummary?: string;
}

export type ThemeMode = 'dark' | 'light';

export interface AppSettings {
  themeMode: ThemeMode;
  telegramBotConnected: boolean;
  notificationsEnabled: boolean;
  customFont?: string;
  customLogo?: string;
}

// API Types
export interface ProjectInput {
  user_id: string;
  project_name: string;
  project_goal: string;
  num_phases?: number;
}

export interface UpdateInput {
  project_id: string;
  update_text: string;
  type: 'daily' | 'weekly';
}