import { create } from 'zustand';
import { supabase } from '../lib/supabase';
import type { Database } from '../types/supabase';

type Message = Database['public']['Tables']['messages']['Row'];

interface MessageState {
  messages: Message[];
  isLoading: boolean;
  error: string | null;
  sendMessage: (content: string, senderId: string) => Promise<void>;
  fetchMessages: () => Promise<void>;
}

export const useMessageStore = create<MessageState>((set, get) => ({
  messages: [],
  isLoading: false,
  error: null,

  sendMessage: async (content: string, senderId: string) => {
    try {
      const { error } = await supabase
        .from('messages')
        .insert([{ content, sender_id: senderId }]);

      if (error) throw error;
    } catch (error) {
      set({ error: (error as Error).message });
    }
  },

  fetchMessages: async () => {
    set({ isLoading: true });
    try {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .order('created_at', { ascending: true });

      if (error) throw error;
      set({ messages: data || [], isLoading: false });
    } catch (error) {
      set({ error: (error as Error).message, isLoading: false });
    }
  },
}));

// Set up real-time subscription
supabase
  .channel('messages')
  .on('postgres_changes', 
    { event: 'INSERT', schema: 'public', table: 'messages' },
    (payload) => {
      const message = payload.new as Message;
      useMessageStore.setState((state) => ({
        messages: [...state.messages, message]
      }));
    }
  )
  .subscribe();