import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from './context/ThemeContext';
import RequireAuth from './components/auth/RequireAuth';
import Layout from './components/layout/Layout';
import Dashboard from './pages/Dashboard';
import ProgressTracker from './pages/ProgressTracker';
import Messages from './pages/Messages';
import Files from './pages/Files';
import Settings from './pages/Settings';
import SignIn from './pages/SignIn';
import SignUp from './pages/SignUp';

function App() {
  return (
    <div className="min-h-screen bg-background">
      <ThemeProvider>
        <BrowserRouter>
          <Routes>
            {/* Public routes */}
            <Route path="/sign-in" element={<SignIn />} />
            <Route path="/sign-up" element={<SignUp />} />

            {/* Protected routes */}
            <Route path="/" element={
              <RequireAuth>
                <Layout />
              </RequireAuth>
            }>
              <Route index element={<Dashboard />} />
              <Route path="progress" element={<ProgressTracker />} />
              <Route path="messages" element={<Messages />} />
              <Route path="files" element={<Files />} />
              <Route path="settings" element={<Settings />} />
              <Route path="*" element={<Navigate to="/\" replace />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </ThemeProvider>
    </div>
  );
}

export default App;