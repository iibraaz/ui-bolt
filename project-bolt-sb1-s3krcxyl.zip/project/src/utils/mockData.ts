import { Project, Phase, Task, Update, Message, FileItem, User } from '../types';

// Mock Users
export const mockUsers: User[] = [
  {
    id: '1',
    name: 'Alex Johnson',
    role: 'owner',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '2',
    name: 'Taylor Chen',
    role: 'engineer',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '3',
    name: 'Morgan Smith',
    role: 'engineer',
    avatar: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '4',
    name: 'Riley Brown',
    role: 'engineer',
    avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  }
];

// Mock Projects
export const mockProjects: Project[] = [
  {
    id: '1',
    name: 'Mobile App Development',
    description: 'Build a cross-platform mobile application with React Native',
    progress: 65,
    startDate: '2025-01-15',
    endDate: '2025-06-30',
    phases: [
      {
        id: '1-1',
        projectId: '1',
        name: 'Design',
        description: 'UI/UX design for the mobile application',
        progress: 100,
        startDate: '2025-01-15',
        endDate: '2025-02-15',
        tasks: []
      },
      {
        id: '1-2',
        projectId: '1',
        name: 'Frontend Development',
        description: 'Implement the UI components and screens',
        progress: 75,
        startDate: '2025-02-16',
        endDate: '2025-04-15',
        tasks: []
      },
      {
        id: '1-3',
        projectId: '1',
        name: 'Backend Integration',
        description: 'Connect to APIs and implement data flow',
        progress: 40,
        startDate: '2025-03-01',
        endDate: '2025-05-15',
        tasks: []
      },
      {
        id: '1-4',
        projectId: '1',
        name: 'Testing',
        description: 'Quality assurance and bug fixing',
        progress: 20,
        startDate: '2025-04-15',
        endDate: '2025-06-15',
        tasks: []
      }
    ]
  },
  {
    id: '2',
    name: 'Web Platform Redesign',
    description: 'Modernize the existing web platform with new features',
    progress: 30,
    startDate: '2025-02-01',
    endDate: '2025-07-31',
    phases: []
  }
];

// Mock Tasks
export const mockTasks: Task[] = [
  {
    id: '101',
    phaseId: '1-2',
    title: 'Implement authentication screens',
    description: 'Create login, signup, and password reset screens',
    assignee: 'Taylor Chen',
    status: 'completed',
    dueDate: '2025-03-01',
    priority: 'high'
  },
  {
    id: '102',
    phaseId: '1-2',
    title: 'Build navigation system',
    description: 'Implement tab navigation and screen transitions',
    assignee: 'Morgan Smith',
    status: 'in-progress',
    dueDate: '2025-03-15',
    priority: 'medium'
  },
  {
    id: '103',
    phaseId: '1-3',
    title: 'Set up API client',
    description: 'Configure API client with auth tokens and request/response interceptors',
    assignee: 'Riley Brown',
    status: 'in-progress',
    dueDate: '2025-03-25',
    priority: 'high'
  },
  {
    id: '104',
    phaseId: '1-3',
    title: 'Implement offline data sync',
    description: 'Create system for offline data storage and synchronization',
    assignee: 'Taylor Chen',
    status: 'todo',
    dueDate: '2025-04-10',
    priority: 'medium'
  },
  {
    id: '105',
    phaseId: '1-4',
    title: 'Perform unit testing',
    description: 'Write and run unit tests for all components',
    assignee: 'Morgan Smith',
    status: 'todo',
    dueDate: '2025-05-01',
    priority: 'medium'
  }
];

// Assign tasks to phases
mockProjects[0].phases.forEach(phase => {
  phase.tasks = mockTasks.filter(task => task.phaseId === phase.id);
});

// Mock Updates - REMOVED ALL FAKE UPDATES
export const mockUpdates: Update[] = [];

// Mock Messages
export const mockMessages: Message[] = [
  {
    id: '1',
    senderId: '1',
    senderName: 'Alex Johnson',
    senderAvatar: mockUsers[0].avatar,
    recipientId: '2',
    recipientName: 'Taylor Chen',
    content: 'Great job on the authentication screens! Can you help Morgan with the animation issues?',
    timestamp: '2025-03-10T10:15:00Z',
    isTask: false
  },
  {
    id: '2',
    senderId: '1',
    senderName: 'Alex Johnson',
    senderAvatar: mockUsers[0].avatar,
    recipientId: '3',
    recipientName: 'Morgan Smith',
    content: 'Please investigate React Native Reanimated as an alternative for the animations',
    timestamp: '2025-03-11T15:30:00Z',
    isTask: true,
    taskStatus: 'in-progress'
  },
  {
    id: '3',
    senderId: '1',
    senderName: 'Alex Johnson',
    senderAvatar: mockUsers[0].avatar,
    recipientId: '4',
    recipientName: 'Riley Brown',
    content: 'I\'ve sent you the API documentation via email. Let me know if you need anything else.',
    timestamp: '2025-03-12T13:45:00Z',
    isTask: false
  },
  {
    id: '4',
    senderId: '1',
    senderName: 'Alex Johnson',
    senderAvatar: mockUsers[0].avatar,
    recipientId: '2',
    recipientName: 'Taylor Chen',
    content: 'Schedule a team sync for tomorrow to discuss progress and blockers',
    timestamp: '2025-03-13T17:20:00Z',
    isTask: true,
    taskStatus: 'todo'
  }
];

// Mock Files
export const mockFiles: FileItem[] = [
  {
    id: '1',
    name: 'Authentication_Flow_Diagram.pdf',
    uploadedBy: 'Taylor Chen',
    uploadDate: '2025-03-09T16:30:00Z',
    size: 2456789,
    type: 'application/pdf',
    url: '#',
    aiSummary: 'Detailed diagram showing the authentication flow including login, signup, password reset, and biometric authentication processes.'
  },
  {
    id: '2',
    name: 'API_Integration_Specs.docx',
    uploadedBy: 'Riley Brown',
    uploadDate: '2025-03-12T10:15:00Z',
    size: 1845623,
    type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    url: '#',
    aiSummary: 'Technical specifications for API integration including endpoints, data formats, authentication requirements, and error handling.'
  },
  {
    id: '3',
    name: 'UI_Component_Library.sketch',
    uploadedBy: 'Morgan Smith',
    uploadDate: '2025-03-08T09:45:00Z',
    size: 12578945,
    type: 'application/octet-stream',
    url: '#',
    aiSummary: 'Comprehensive UI component library including all screens, components, and assets for the mobile application.'
  },
  {
    id: '4',
    name: 'Performance_Metrics_March.xlsx',
    uploadedBy: 'Riley Brown',
    uploadDate: '2025-03-14T14:20:00Z',
    size: 987654,
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    url: '#',
    aiSummary: 'Monthly performance metrics showing application load times, API response times, and user engagement across different devices.'
  }
];

// Get counts for dashboard widgets
export const getDashboardCounts = () => {
  return {
    totalProjects: mockProjects.length,
    totalPhases: mockProjects.reduce((sum, project) => sum + project.phases.length, 0),
    dueTasks: mockTasks.filter(task => task.status !== 'completed').length,
    completedTasks: mockTasks.filter(task => task.status === 'completed').length
  };
};

// Get weekly activity data for charts
export const getWeeklyActivityData = () => {
  return {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [
      {
        label: 'Tasks Completed',
        data: [3, 5, 2, 4, 6, 1, 0]
      },
      {
        label: 'Updates Received',
        data: [5, 7, 4, 6, 8, 2, 1]
      }
    ]
  };
};

// Get phase progress data for charts
export const getPhaseProgressData = () => {
  return {
    labels: mockProjects[0].phases.map(phase => phase.name),
    datasets: [
      {
        label: 'Progress (%)',
        data: mockProjects[0].phases.map(phase => phase.progress)
      }
    ]
  };
};