import React from 'react';
import SummaryWidget from '../components/dashboard/SummaryWidget';
import ActivityFeed from '../components/dashboard/ActivityFeed';
import Card from '../components/ui/Card';
import ProgressCircle from '../components/ui/ProgressCircle';
import BarChart from '../components/charts/BarChart';
import LineChart from '../components/charts/LineChart';
import { FileText, Users, Target, CheckCircle } from 'lucide-react';
import { mockUpdates } from '../utils/mockData';
import { getDashboardCounts, getWeeklyActivityData, getPhaseProgressData } from '../utils/mockData';

const Dashboard: React.FC = () => {
  const counts = getDashboardCounts();
  const weeklyData = getWeeklyActivityData();
  const phaseData = getPhaseProgressData();
  
  return (
    <div className="space-y-6">
      <Card className="bg-[#171717] border border-gray-800">
        <div>
          <h1 className="text-2xl font-bold text-white">
            Welcome back!
          </h1>
          <p className="text-gray-300 mt-1">
            Here's what's happening with your projects today
          </p>
        </div>
      </Card>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <SummaryWidget 
          title="Total Projects" 
          value={counts.totalProjects} 
          icon={<FileText size={20} />}
          color="#FF5D2B"
        />
        
        <SummaryWidget 
          title="Project Phases" 
          value={counts.totalPhases} 
          icon={<Target size={20} />}
          color="#3B82F6"
        />
        
        <SummaryWidget 
          title="Due Tasks" 
          value={counts.dueTasks} 
          icon={<Users size={20} />}
          color="#F59E0B"
          change={{ value: 12, positive: false }}
        />
        
        <SummaryWidget 
          title="Completed Tasks" 
          value={counts.completedTasks} 
          icon={<CheckCircle size={20} />}
          color="#10B981"
          change={{ value: 8, positive: true }}
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card 
          title="Project Progress" 
          subtitle="Mobile App Development"
          className="lg:col-span-1"
        >
          <div className="flex flex-col items-center justify-center h-64 bg-gray-50/5 rounded-lg">
            <ProgressCircle 
              value={65} 
              size={180}
              strokeWidth={12}
              labelFontSize={28}
              bgColor="#2A2A2A"
            />
            
            <div className="mt-4 text-center">
              <p className="text-sm text-gray-400">
                Current Sprint Progress
              </p>
              <p className="text-xl font-semibold text-white mt-1">
                Sprint 4 / 6
              </p>
            </div>
          </div>
        </Card>
        
        <Card 
          title="Weekly Activity" 
          className="lg:col-span-2"
        >
          <div className="h-64">
            <LineChart data={weeklyData} height={250} />
          </div>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card 
          title="Phase Progress" 
          subtitle="Mobile App Development"
          className="lg:col-span-1"
        >
          <div className="h-80">
            <BarChart data={phaseData} height={280} />
          </div>
        </Card>
        
        <div className="lg:col-span-2">
          <ActivityFeed />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;