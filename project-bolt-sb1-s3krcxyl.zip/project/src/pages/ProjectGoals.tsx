import React, { useState } from 'react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import { ChevronDown, ChevronUp, Mic, Send, Plus, Target } from 'lucide-react';
import { api } from '../lib/api';

const ProjectGoals: React.FC = () => {
  const [expandedPhases, setExpandedPhases] = useState<string[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [goalInput, setGoalInput] = useState('');
  const [currentProject, setCurrentProject] = useState<{
    name: string;
    goal: string;
    plan: string;
  } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const togglePhase = (phaseId: string) => {
    setExpandedPhases(prev => 
      prev.includes(phaseId) 
        ? prev.filter(id => id !== phaseId) 
        : [...prev, phaseId]
    );
  };

  const toggleRecording = () => {
    setIsRecording(!isRecording);
  };

  const handleSubmitGoal = async () => {
    if (!goalInput.trim()) return;

    setIsSubmitting(true);
    try {
      const result = await api.createProject({
        user_id: '1', // Hardcoded for demo
        project_name: 'New Project',
        project_goal: goalInput,
        num_phases: 4
      });

      setCurrentProject({
        name: 'New Project',
        goal: goalInput,
        plan: result.plan
      });
      setGoalInput('');
    } catch (error) {
      console.error('Failed to create project:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <h1 className="text-2xl font-bold text-white mb-4 sm:mb-0">Project Goals</h1>
      </div>
      
      <Card title="Add New Goal" icon={<Target size={18} />}>
        <div className="mb-4">
          <label htmlFor="goal-input" className="block text-sm font-medium text-gray-400 mb-1">
            Enter your project goal
          </label>
          <div className="flex">
            <textarea
              id="goal-input"
              rows={3}
              className="w-full bg-gray-800 border border-gray-700 rounded-md py-2 px-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#FF5D2B]/50 focus:border-transparent"
              placeholder="Describe your project goal or upload a voice message..."
              value={goalInput}
              onChange={(e) => setGoalInput(e.target.value)}
            />
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Button
              variant="ghost"
              size="sm"
              icon={<Mic size={16} />}
              className={isRecording ? 'text-red-500 animate-pulse' : ''}
              onClick={toggleRecording}
            >
              {isRecording ? 'Recording...' : 'Voice Input'}
            </Button>
            <span className="text-xs text-gray-500 ml-2">or</span>
            <Button
              variant="ghost"
              size="sm"
              icon={<Plus size={16} />}
              className="ml-2"
            >
              Upload File
            </Button>
          </div>
          
          <Button
            variant="primary"
            size="sm"
            icon={<Send size={16} />}
            onClick={handleSubmitGoal}
            disabled={!goalInput.trim() || isSubmitting}
          >
            {isSubmitting ? 'Processing...' : 'Submit Goal'}
          </Button>
        </div>
      </Card>
      
      {currentProject ? (
        <div className="mt-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-white">Current Project: {currentProject.name}</h2>
          </div>
          
          <Card className="mb-6">
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium text-gray-400">Project Goal</h3>
                <p className="text-white mt-1">{currentProject.goal}</p>
              </div>
              
              <div className="border-t border-gray-700 pt-4">
                <h3 className="text-sm font-medium text-gray-400">AI-Generated Project Plan</h3>
                <div className="mt-2 text-white whitespace-pre-wrap">{currentProject.plan}</div>
              </div>
            </div>
          </Card>
        </div>
      ) : (
        <Card className="text-center py-8">
          <Target size={48} className="mx-auto text-gray-600 mb-4" />
          <p className="text-gray-400">Submit a project goal to see the AI-generated breakdown</p>
        </Card>
      )}
    </div>
  );
};

export default ProjectGoals;