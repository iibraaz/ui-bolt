import { SignUp } from "@clerk/clerk-react";

const SignUpPage = () => (
  <div className="min-h-screen flex items-center justify-center bg-[#171717]">
    <div className="w-full max-w-md">
      <SignUp 
        appearance={{
          elements: {
            rootBox: "mx-auto",
            card: "bg-[#171717] border border-gray-700",
            headerTitle: "text-white",
            headerSubtitle: "text-gray-400",
            socialButtonsBlockButton: "bg-gray-800 border border-gray-700 text-white hover:bg-gray-700",
            dividerLine: "bg-gray-700",
            dividerText: "text-gray-400",
            formFieldLabel: "text-gray-300",
            formFieldInput: "bg-gray-800 border-gray-700 text-white",
            formButtonPrimary: "bg-[#FF5D2B] hover:bg-[#FF7A50]",
            footerActionLink: "text-[#FF5D2B] hover:text-[#FF7A50]",
          },
        }}
      />
    </div>
  </div>
);

export default SignUpPage;