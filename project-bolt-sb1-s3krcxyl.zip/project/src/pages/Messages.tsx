import React, { useState, useEffect, useRef } from 'react';
import { Send, Mic } from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

const Messages: React.FC = () => {
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [sessionId] = useState(() => `session-${Date.now()}`);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isProcessing) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: input.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsProcessing(true);

    try {
      const response = await fetch('https://project-tracker-49km.onrender.com/chat-command', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          session_id: sessionId,
          message: userMessage.content
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to send message');
      }

      const result = await response.json();
      
      let assistantContent = '';
      
      if (result.draft_email) {
        assistantContent = `Here's the draft email:\n\nTo: ${result.draft_email.to}\nSubject: ${result.draft_email.subject}\n\n${result.draft_email.message}\n\nWould you like me to send this email?`;
      } else {
        assistantContent = result.message || result.reply || 'I processed your request.';
      }

      const assistantMessage: Message = {
        id: Date.now().toString(),
        type: 'assistant',
        content: assistantContent,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      const errorMessage: Message = {
        id: Date.now().toString(),
        type: 'assistant',
        content: 'Sorry, I encountered an error while processing your request.',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="h-[calc(100vh-5rem)] max-h-[calc(100vh-5rem)] flex flex-col">
      <div className="flex-1 p-4 space-y-4 overflow-hidden">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center space-y-4">
            <div className="relative w-32 h-32">
              <div className="absolute inset-0 rounded-full bg-[#FFA500]/30 blur-2xl animate-pulse"></div>
              <div 
                className="absolute inset-0 rounded-full bg-gradient-to-r from-[#FFA500] to-[#FFD700] opacity-90"
                style={{
                  animation: 'rotate 8s linear infinite, morph 4s ease-in-out infinite',
                }}
              ></div>
              <div 
                className="absolute inset-0 rounded-full bg-gradient-to-br from-white/50 to-transparent"
                style={{
                  animation: 'rotate 8s linear infinite',
                  mixBlendMode: 'overlay',
                }}
              ></div>
              <div className="absolute inset-4 rounded-full bg-[#FFA500]/60 blur-md"></div>
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl font-semibold text-white">How can I help you today?</h2>
              <p className="text-gray-400">Ask me anything about your projects or tasks!</p>
            </div>
          </div>
        ) : (
          <div className="h-full overflow-y-auto space-y-4 pr-2">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                    message.type === 'user'
                      ? 'bg-[#FF5D2B] text-white'
                      : 'bg-gray-800 text-gray-100'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{message.content}</p>
                  <p className="text-xs mt-1 opacity-60">
                    {message.timestamp.toLocaleTimeString()}
                  </p>
                </div>
              </div>
            ))}
            {isProcessing && (
              <div className="flex justify-start">
                <div className="bg-gray-800 rounded-2xl px-4 py-3">
                  <div className="flex space-x-2">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="p-4 border-t border-gray-800">
        <div className="relative flex items-center">
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your message..."
            className="w-full bg-transparent text-white rounded-full py-3 pl-4 pr-12 border border-white/60 focus:outline-none focus:ring-2 focus:ring-[#FF5D2B]/50"
            disabled={isProcessing}
          />
          <div className="absolute right-2 flex items-center space-x-2">
            <button
              type="button"
              className="p-2 text-gray-400 hover:text-white transition-colors"
              onClick={() => {/* TODO: Implement voice input */}}
            >
              <Mic size={20} />
            </button>
            <button
              type="submit"
              disabled={!input.trim() || isProcessing}
              className="p-2 text-[#FF5D2B] hover:text-[#FF7A50] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send size={20} />
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default Messages;