import React, { useState, useEffect } from 'react';
import Card from '../components/ui/Card';
import Badge from '../components/ui/Badge';
import Button from '../components/ui/Button';
import { Calendar, Clock, Filter, RefreshCw, MessageSquare, Trash2, CheckSquare, Square, Wifi, WifiOff, AlertCircle } from 'lucide-react';
import { supabase, subscribeToTelegramUpdates, getRealtimeStatus, forceReconnect } from '../lib/supabase';

interface TelegramUpdate {
  id: string;
  message_id: string;
  chat_id: string;
  from_id: string;
  from_name: string;
  content: string;
  category: 'progress' | 'issue' | 'need';
  created_at: string;
}

const ProgressTracker: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState<'all' | 'daily' | 'weekly' | 'monthly'>('all');
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'progress' | 'issue' | 'need'>('all');
  const [updates, setUpdates] = useState<TelegramUpdate[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedMessages, setSelectedMessages] = useState<Set<string>>(new Set());
  const [isDeleting, setIsDeleting] = useState(false);
  const [selectionMode, setSelectionMode] = useState(false);
  const [realtimeConnected, setRealtimeConnected] = useState(false);
  const [lastUpdateTime, setLastUpdateTime] = useState<Date | null>(null);

  const fetchUpdates = async () => {
    try {
      console.log('🔄 Fetching telegram updates from ProgressTracker...');
      
      const { data, error } = await supabase
        .from('telegram_updates')
        .select('*')
        .order('created_at', { ascending: false });

      console.log('📊 Query result:', { data, error });

      if (error) {
        console.error('❌ Supabase error:', error);
        throw error;
      }
      
      console.log('✅ Fetched updates:', data?.length || 0, 'items');
      setUpdates(data || []);
      setError(null);
      setLastUpdateTime(new Date());
    } catch (err) {
      console.error('❌ Error fetching updates:', err);
      setError(`Failed to load updates: ${err instanceof Error ? err.message : 'Unknown error'}`);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchUpdates();
    setRefreshing(false);
  };

  const handleForceReconnect = () => {
    console.log('🔄 User requested force reconnect...');
    forceReconnect();
    setTimeout(() => {
      setRealtimeConnected(getRealtimeStatus());
    }, 1000);
  };

  const toggleMessageSelection = (messageId: string) => {
    const newSelected = new Set(selectedMessages);
    if (newSelected.has(messageId)) {
      newSelected.delete(messageId);
    } else {
      newSelected.add(messageId);
    }
    setSelectedMessages(newSelected);
  };

  const selectAllMessages = () => {
    const allMessageIds = new Set(filteredUpdates.map(update => update.id));
    setSelectedMessages(allMessageIds);
  };

  const deselectAllMessages = () => {
    setSelectedMessages(new Set());
  };

  const deleteSelectedMessages = async () => {
    if (selectedMessages.size === 0) return;

    setIsDeleting(true);
    setError(null);
    
    try {
      console.log('🗑️ Deleting selected messages:', Array.from(selectedMessages));
      
      const { error } = await supabase
        .from('telegram_updates')
        .delete()
        .in('id', Array.from(selectedMessages));

      if (error) {
        console.error('❌ Delete error:', error);
        throw error;
      }

      console.log('✅ Successfully deleted messages from database');
      
      // Remove deleted messages from local state immediately
      setUpdates(prev => {
        const filtered = prev.filter(update => !selectedMessages.has(update.id));
        console.log('📊 Local state updated, remaining messages:', filtered.length);
        return filtered;
      });
      
      // Clear selection and exit selection mode
      setSelectedMessages(new Set());
      setSelectionMode(false);
      
      console.log('🎉 Delete operation completed successfully');
    } catch (err) {
      console.error('❌ Error deleting messages:', err);
      setError(`Failed to delete messages: ${err instanceof Error ? err.message : 'Unknown error'}`);
    } finally {
      setIsDeleting(false);
    }
  };

  // Handle category filter clicks
  const handleCategoryFilter = (category: 'progress' | 'issue' | 'need') => {
    if (categoryFilter === category) {
      // If clicking the same category, toggle to 'all'
      setCategoryFilter('all');
    } else {
      // Otherwise, set to the clicked category
      setCategoryFilter(category);
    }
  };

  useEffect(() => {
    console.log('🚀 Setting up ProgressTracker component...');
    
    const loadUpdates = async () => {
      setLoading(true);
      await fetchUpdates();
      setLoading(false);
    };

    // Load initial data
    loadUpdates();

    // Subscribe to real-time updates using global subscription
    const unsubscribe = subscribeToTelegramUpdates((payload) => {
      console.log('🔥 Real-time update received in ProgressTracker:', payload);
      setRealtimeConnected(true);
      setLastUpdateTime(new Date());
      
      if (payload.eventType === 'INSERT') {
        const newUpdate = payload.new as TelegramUpdate;
        setUpdates(prev => {
          // Check if update already exists to prevent duplicates
          const exists = prev.some(update => update.id === newUpdate.id);
          if (exists) {
            console.log('⚠️ Duplicate update detected, skipping');
            return prev;
          }
          console.log('✅ Adding new update to list');
          return [newUpdate, ...prev];
        });
      } else if (payload.eventType === 'DELETE') {
        const deletedUpdate = payload.old as TelegramUpdate;
        console.log('🗑️ Real-time delete event - removing update from list:', deletedUpdate.id);
        setUpdates(prev => {
          const filtered = prev.filter(update => update.id !== deletedUpdate.id);
          console.log('📊 After real-time delete, remaining messages:', filtered.length);
          return filtered;
        });
        // Remove from selection if it was selected
        setSelectedMessages(prev => {
          const newSelected = new Set(prev);
          newSelected.delete(deletedUpdate.id);
          return newSelected;
        });
      } else if (payload.eventType === 'UPDATE') {
        const updatedUpdate = payload.new as TelegramUpdate;
        console.log('📝 Updating existing update in list');
        setUpdates(prev => prev.map(update => 
          update.id === updatedUpdate.id ? updatedUpdate : update
        ));
      }
    });

    // Check connection status periodically
    const statusCheck = setInterval(() => {
      const currentStatus = getRealtimeStatus();
      setRealtimeConnected(currentStatus);
    }, 5000);

    // Auto-refresh every 60 seconds as fallback
    const autoRefresh = setInterval(() => {
      const currentStatus = getRealtimeStatus();
      if (!currentStatus) {
        console.log('🔄 Real-time not connected, auto-refreshing...');
        fetchUpdates();
      }
    }, 60000);

    // Cleanup function
    return () => {
      console.log('🧹 Cleaning up ProgressTracker subscriptions...');
      unsubscribe();
      clearInterval(statusCheck);
      clearInterval(autoRefresh);
    };
  }, []); // Empty dependency array to run only once

  // Format date to "MMM DD, YYYY"
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  // Format time to "hh:mm AM/PM"
  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });
  };

  // Get badge variant based on update category
  const getBadgeVariant = (category: string): 'success' | 'warning' | 'error' => {
    switch (category) {
      case 'progress':
        return 'success';
      case 'issue':
        return 'error';
      case 'need':
        return 'warning';
      default:
        return 'success';
    }
  };

  // Get category label
  const getCategoryLabel = (category: string): string => {
    switch (category) {
      case 'progress':
        return 'Progress';
      case 'issue':
        return 'Issue';
      case 'need':
        return 'Need';
      default:
        return 'Update';
    }
  };

  // Filter updates based on time period
  const filterUpdatesByTime = (updates: TelegramUpdate[]): TelegramUpdate[] => {
    if (activeFilter === 'all') return updates;
    
    const now = new Date();
    const startDate = new Date();
    
    switch (activeFilter) {
      case 'daily':
        startDate.setDate(now.getDate() - 1);
        break;
      case 'weekly':
        startDate.setDate(now.getDate() - 7);
        break;
      case 'monthly':
        startDate.setMonth(now.getMonth() - 1);
        break;
    }
    
    return updates.filter(update => new Date(update.created_at) >= startDate);
  };

  // Filter updates based on category
  const filterUpdatesByCategory = (updates: TelegramUpdate[]): TelegramUpdate[] => {
    if (categoryFilter === 'all') return updates;
    return updates.filter(update => update.category === categoryFilter);
  };

  // Apply all filters
  const filteredUpdates = filterUpdatesByCategory(filterUpdatesByTime(updates));

  // Get counts for each category (based on time filter only)
  const getCategoryCounts = () => {
    const timeFilteredUpdates = filterUpdatesByTime(updates);
    return {
      progress: timeFilteredUpdates.filter(u => u.category === 'progress').length,
      issue: timeFilteredUpdates.filter(u => u.category === 'issue').length,
      need: timeFilteredUpdates.filter(u => u.category === 'need').length,
    };
  };

  const counts = getCategoryCounts();

  if (loading) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold text-white">Progress Tracker</h1>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#FF5D2B]"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Progress Tracker</h1>
          <div className="flex items-center mt-1 space-x-4">
            <div className="flex items-center">
              {realtimeConnected ? (
                <Wifi size={14} className="text-green-400 mr-1" />
              ) : (
                <WifiOff size={14} className="text-red-400 mr-1" />
              )}
              <span className="text-xs text-gray-400">
                {realtimeConnected ? 'Real-time connected' : 'Real-time disconnected'}
              </span>
              {!realtimeConnected && (
                <button
                  onClick={handleForceReconnect}
                  className="ml-2 text-xs text-[#FF5D2B] hover:text-[#FF7A50]"
                >
                  Reconnect
                </button>
              )}
            </div>
            {lastUpdateTime && (
              <span className="text-xs text-gray-500">
                Last update: {formatTime(lastUpdateTime.toISOString())}
              </span>
            )}
          </div>
        </div>
        
        <div className="mt-4 sm:mt-0 flex flex-wrap gap-2">
          <Button 
            variant={activeFilter === 'all' ? 'primary' : 'outline'} 
            size="sm"
            onClick={() => setActiveFilter('all')}
          >
            All Time
          </Button>
          <Button 
            variant={activeFilter === 'daily' ? 'primary' : 'outline'} 
            size="sm"
            onClick={() => setActiveFilter('daily')}
          >
            Daily
          </Button>
          <Button 
            variant={activeFilter === 'weekly' ? 'primary' : 'outline'} 
            size="sm"
            onClick={() => setActiveFilter('weekly')}
          >
            Weekly
          </Button>
          <Button 
            variant={activeFilter === 'monthly' ? 'primary' : 'outline'} 
            size="sm"
            onClick={() => setActiveFilter('monthly')}
          >
            Monthly
          </Button>
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="p-2 text-gray-400 hover:text-white transition-colors"
            title="Refresh updates"
          >
            <RefreshCw size={16} className={refreshing ? 'animate-spin' : ''} />
          </button>
        </div>
      </div>

      {!realtimeConnected && (
        <div className="bg-yellow-500/10 border border-yellow-500/50 rounded-md p-3 flex items-start">
          <AlertCircle size={18} className="text-yellow-500 mt-0.5 mr-2 flex-shrink-0" />
          <div>
            <p className="text-yellow-500 text-sm font-medium">Real-time connection lost</p>
            <p className="text-yellow-400 text-xs mt-1">
              Updates will refresh automatically every minute. Click "Reconnect" to restore real-time updates.
            </p>
          </div>
        </div>
      )}

      {error && (
        <div className="bg-red-500/10 border border-red-500/50 rounded-md p-3 flex items-start">
          <AlertCircle size={18} className="text-red-500 mt-0.5 mr-2 flex-shrink-0" />
          <div>
            <p className="text-red-500 text-sm font-medium">Error</p>
            <p className="text-red-400 text-xs mt-1">{error}</p>
          </div>
        </div>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card 
          hoverable
          className={`cursor-pointer border-l-4 transition-all duration-200 ${
            categoryFilter === 'progress' 
              ? 'border-l-green-500 bg-green-500/5 ring-2 ring-green-500/20' 
              : 'border-l-transparent hover:border-l-green-500/50'
          }`}
          onClick={() => handleCategoryFilter('progress')}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className={`p-2 rounded-md mr-3 transition-colors ${
                categoryFilter === 'progress' ? 'bg-green-500/30' : 'bg-green-500/20'
              }`}>
                <span className="text-green-400">✅</span>
              </div>
              <div>
                <h3 className={`font-medium transition-colors ${
                  categoryFilter === 'progress' ? 'text-green-400' : 'text-white'
                }`}>
                  Progress
                </h3>
                <p className="text-sm text-gray-400">Completed tasks and milestones</p>
              </div>
            </div>
            <div className={`text-2xl font-bold transition-colors ${
              categoryFilter === 'progress' ? 'text-green-300' : 'text-green-400'
            }`}>
              {counts.progress}
            </div>
          </div>
          {categoryFilter === 'progress' && (
            <div className="mt-2 text-xs text-green-400">
              ✓ Filtering by Progress updates
            </div>
          )}
        </Card>
        
        <Card 
          hoverable
          className={`cursor-pointer border-l-4 transition-all duration-200 ${
            categoryFilter === 'issue' 
              ? 'border-l-red-500 bg-red-500/5 ring-2 ring-red-500/20' 
              : 'border-l-transparent hover:border-l-red-500/50'
          }`}
          onClick={() => handleCategoryFilter('issue')}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className={`p-2 rounded-md mr-3 transition-colors ${
                categoryFilter === 'issue' ? 'bg-red-500/30' : 'bg-red-500/20'
              }`}>
                <span className="text-red-400">⚠️</span>
              </div>
              <div>
                <h3 className={`font-medium transition-colors ${
                  categoryFilter === 'issue' ? 'text-red-400' : 'text-white'
                }`}>
                  Issues
                </h3>
                <p className="text-sm text-gray-400">Blockers and technical challenges</p>
              </div>
            </div>
            <div className={`text-2xl font-bold transition-colors ${
              categoryFilter === 'issue' ? 'text-red-300' : 'text-red-400'
            }`}>
              {counts.issue}
            </div>
          </div>
          {categoryFilter === 'issue' && (
            <div className="mt-2 text-xs text-red-400">
              ⚠️ Filtering by Issue reports
            </div>
          )}
        </Card>
        
        <Card 
          hoverable
          className={`cursor-pointer border-l-4 transition-all duration-200 ${
            categoryFilter === 'need' 
              ? 'border-l-yellow-500 bg-yellow-500/5 ring-2 ring-yellow-500/20' 
              : 'border-l-transparent hover:border-l-yellow-500/50'
          }`}
          onClick={() => handleCategoryFilter('need')}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className={`p-2 rounded-md mr-3 transition-colors ${
                categoryFilter === 'need' ? 'bg-yellow-500/30' : 'bg-yellow-500/20'
              }`}>
                <span className="text-yellow-400">📌</span>
              </div>
              <div>
                <h3 className={`font-medium transition-colors ${
                  categoryFilter === 'need' ? 'text-yellow-400' : 'text-white'
                }`}>
                  Needs
                </h3>
                <p className="text-sm text-gray-400">Resources and assistance required</p>
              </div>
            </div>
            <div className={`text-2xl font-bold transition-colors ${
              categoryFilter === 'need' ? 'text-yellow-300' : 'text-yellow-400'
            }`}>
              {counts.need}
            </div>
          </div>
          {categoryFilter === 'need' && (
            <div className="mt-2 text-xs text-yellow-400">
              📌 Filtering by Resource needs
            </div>
          )}
        </Card>
      </div>
      
      <Card 
        title={`Engineer Updates${categoryFilter !== 'all' ? ` - ${getCategoryLabel(categoryFilter)}` : ''}`}
        icon={<Filter size={18} />}
        contentClassName="p-0"
        headerAction={
          <div className="flex items-center space-x-2">
            {categoryFilter !== 'all' && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setCategoryFilter('all')}
                className="text-gray-400 hover:text-white"
              >
                Clear Filter
              </Button>
            )}
            {selectionMode && (
              <>
                <span className="text-xs text-gray-400">
                  {selectedMessages.size} selected
                </span>
                {selectedMessages.size > 0 && (
                  <Button
                    variant="outline"
                    size="sm"
                    icon={<Trash2 size={14} />}
                    onClick={deleteSelectedMessages}
                    disabled={isDeleting}
                    className="text-red-400 border-red-400 hover:bg-red-400/10"
                  >
                    {isDeleting ? 'Deleting...' : 'Delete'}
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setSelectionMode(false);
                    setSelectedMessages(new Set());
                  }}
                >
                  Cancel
                </Button>
              </>
            )}
            {!selectionMode && filteredUpdates.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectionMode(true)}
              >
                Select
              </Button>
            )}
            <button
              onClick={handleRefresh}
              disabled={refreshing}
              className="p-1 text-gray-400 hover:text-white transition-colors"
              title="Refresh updates"
            >
              <RefreshCw size={16} className={refreshing ? 'animate-spin' : ''} />
            </button>
          </div>
        }
      >
        {selectionMode && filteredUpdates.length > 0 && (
          <div className="p-4 border-b border-gray-700 bg-gray-800/50">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <button
                  onClick={selectAllMessages}
                  className="flex items-center text-sm text-[#FF5D2B] hover:text-[#FF7A50]"
                >
                  <CheckSquare size={16} className="mr-1" />
                  Select All
                </button>
                <button
                  onClick={deselectAllMessages}
                  className="flex items-center text-sm text-gray-400 hover:text-white"
                >
                  <Square size={16} className="mr-1" />
                  Deselect All
                </button>
              </div>
              <span className="text-sm text-gray-400">
                {selectedMessages.size} of {filteredUpdates.length} selected
              </span>
            </div>
          </div>
        )}
        
        <div className="divide-y divide-gray-700">
          {filteredUpdates.length === 0 && !error ? (
            <div className="p-6 text-center text-gray-500">
              <MessageSquare size={48} className="mx-auto mb-2 opacity-50" />
              <p>
                {categoryFilter === 'all' 
                  ? 'No updates match your current filters'
                  : `No ${getCategoryLabel(categoryFilter).toLowerCase()} updates found`
                }
              </p>
              <p className="text-xs mt-1">
                {updates.length === 0 
                  ? 'Messages sent to your Telegram bot will appear here automatically'
                  : categoryFilter !== 'all'
                    ? `Try adjusting your time period filter or check other categories`
                    : 'Try adjusting your time period or category filters'
                }
              </p>
              {categoryFilter !== 'all' && (
                <button 
                  onClick={() => setCategoryFilter('all')}
                  className="mt-2 text-sm text-[#FF5D2B] hover:text-[#FF7A50]"
                >
                  Show All Categories
                </button>
              )}
              <button 
                onClick={handleRefresh}
                className="mt-2 ml-2 text-sm text-[#FF5D2B] hover:text-[#FF7A50]"
              >
                Refresh
              </button>
            </div>
          ) : (
            filteredUpdates.map((update) => (
              <div 
                key={update.id} 
                className={`p-4 transition-colors ${
                  selectionMode 
                    ? 'hover:bg-gray-800/50 cursor-pointer' 
                    : 'hover:bg-gray-800/50'
                } ${
                  selectedMessages.has(update.id) 
                    ? 'bg-[#FF5D2B]/10 border-l-4 border-l-[#FF5D2B]' 
                    : ''
                }`}
                onClick={() => selectionMode && toggleMessageSelection(update.id)}
              >
                <div className="flex items-start space-x-4">
                  {selectionMode && (
                    <div className="flex-shrink-0 pt-1">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleMessageSelection(update.id);
                        }}
                        className="text-gray-400 hover:text-white"
                      >
                        {selectedMessages.has(update.id) ? (
                          <CheckSquare size={20} className="text-[#FF5D2B]" />
                        ) : (
                          <Square size={20} />
                        )}
                      </button>
                    </div>
                  )}
                  
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-full overflow-hidden bg-[#FF5D2B]/20">
                      <div className="w-full h-full flex items-center justify-center text-[#FF5D2B]">
                        {update.from_name.charAt(0).toUpperCase()}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                      <p className="text-sm font-medium text-white">
                        {update.from_name}
                      </p>
                      <div className="mt-1 sm:mt-0 flex items-center text-xs text-gray-500">
                        <Calendar size={12} className="mr-1" />
                        <span>{formatDate(update.created_at)}</span>
                        <span className="mx-1">•</span>
                        <Clock size={12} className="mr-1" />
                        <span>{formatTime(update.created_at)}</span>
                      </div>
                    </div>
                    
                    <div className="mt-2 flex items-start">
                      <Badge variant={getBadgeVariant(update.category)} className="mt-0.5 mr-2">
                        {getCategoryLabel(update.category)}
                      </Badge>
                      <p className="text-gray-300">
                        {update.content}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </Card>
    </div>
  );
};

export default ProgressTracker;