import React, { useState } from 'react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Badge from '../components/ui/Badge';
import { FileText, Download, Eye, Search, Upload, Filter, FileImage, File as FilePdf, FileSpreadsheet, FileCode } from 'lucide-react';
import { mockFiles } from '../utils/mockData';
import { FileItem } from '../types';

const Files: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFile, setSelectedFile] = useState<FileItem | null>(null);
  
  // Format file size
  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };
  
  // Format date
  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };
  
  // Get file icon based on file type
  const getFileIcon = (fileType: string) => {
    if (fileType.includes('image')) return <FileImage size={20} />;
    if (fileType.includes('pdf')) return <FilePdf size={20} />;
    if (fileType.includes('spreadsheet') || fileType.includes('excel')) return <FileSpreadsheet size={20} />;
    if (fileType.includes('code') || fileType.includes('javascript') || fileType.includes('html')) return <FileCode size={20} />;
    return <FileText size={20} />;
  };
  
  // Filter files based on search query
  const filteredFiles = mockFiles.filter(file => 
    file.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    file.aiSummary?.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <h1 className="text-2xl font-bold text-white mb-4 sm:mb-0">Files</h1>
        
        <Button 
          variant="primary" 
          size="sm"
          icon={<Upload size={16} />}
        >
          Upload File
        </Button>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card contentClassName="p-0">
            <div className="p-4 border-b border-gray-700">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search files..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-gray-800 border border-gray-700 rounded-md py-2 pl-10 pr-4 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#FF5D2B]/50 focus:border-transparent"
                />
                <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                  <Search size={16} />
                </div>
                
                {searchQuery && (
                  <button
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-white"
                    onClick={() => setSearchQuery('')}
                  >
                    <span className="text-sm">✕</span>
                  </button>
                )}
              </div>
            </div>
            
            <div className="divide-y divide-gray-700">
              {filteredFiles.length === 0 ? (
                <div className="p-6 text-center text-gray-500">
                  No files match your search
                </div>
              ) : (
                filteredFiles.map((file) => (
                  <div 
                    key={file.id} 
                    className={`p-4 hover:bg-gray-800/50 transition-colors cursor-pointer ${
                      selectedFile?.id === file.id ? 'bg-gray-800/50' : ''
                    }`}
                    onClick={() => setSelectedFile(file)}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="bg-gray-700 p-2 rounded-md">
                        {getFileIcon(file.type)}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                          <h3 className="text-sm font-medium text-white truncate">
                            {file.name}
                          </h3>
                          <div className="mt-1 sm:mt-0 flex items-center text-xs text-gray-500">
                            <span>{formatFileSize(file.size)}</span>
                            <span className="mx-1">•</span>
                            <span>{formatDate(file.uploadDate)}</span>
                          </div>
                        </div>
                        
                        <p className="mt-1 text-xs text-gray-400 line-clamp-1">
                          Uploaded by {file.uploadedBy}
                        </p>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </Card>
        </div>
        
        <div className="lg:col-span-1">
          {selectedFile ? (
            <Card 
              title="File Details"
              className="h-full"
              footer={
                <div className="flex justify-between">
                  <Button 
                    variant="outline" 
                    size="sm"
                    icon={<Eye size={16} />}
                  >
                    Preview
                  </Button>
                  <Button 
                    variant="primary" 
                    size="sm"
                    icon={<Download size={16} />}
                  >
                    Download
                  </Button>
                </div>
              }
            >
              <div className="space-y-4">
                <div className="flex justify-center mb-4">
                  <div className="bg-gray-700 p-4 rounded-md">
                    {getFileIcon(selectedFile.type)}
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium text-white mb-2">{selectedFile.name}</h3>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Size:</span>
                      <span className="text-white">{formatFileSize(selectedFile.size)}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-gray-400">Uploaded by:</span>
                      <span className="text-white">{selectedFile.uploadedBy}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-gray-400">Date:</span>
                      <span className="text-white">{formatDate(selectedFile.uploadDate)}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-gray-400">Type:</span>
                      <span className="text-white">{selectedFile.type.split('/').pop()}</span>
                    </div>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-gray-700">
                  <h4 className="text-sm font-medium text-white mb-2">AI Summary</h4>
                  <p className="text-sm text-gray-300">
                    {selectedFile.aiSummary || 'No summary available'}
                  </p>
                </div>
              </div>
            </Card>
          ) : (
            <Card title="File Details" className="h-full">
              <div className="flex flex-col items-center justify-center h-64 text-center">
                <FileText size={48} className="text-gray-600 mb-4" />
                <p className="text-gray-400">Select a file to view details</p>
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default Files;