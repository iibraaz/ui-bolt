import React, { useState, useEffect } from 'react';
import { Bot, Save, AlertCircle, Clock, RefreshCw, MessageSquare, Copy, ExternalLink, Wifi, WifiOff } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Badge from '../components/ui/Badge';
import { supabase, subscribeToTelegramUpdates } from '../lib/supabase';
import { useUser } from '@clerk/clerk-react';

interface BotInfo {
  username: string;
  first_name: string;
}

interface TelegramUpdate {
  id: string;
  message_id: string;
  chat_id: string;
  from_id: string;
  from_name: string;
  content: string;
  category: 'progress' | 'issue' | 'need';
  created_at: string;
}

const Settings: React.FC = () => {
  const { user } = useUser();
  const [botToken, setBotToken] = useState('');
  const [isActive, setIsActive] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [botInfo, setBotInfo] = useState<BotInfo | null>(null);
  const [recentUpdates, setRecentUpdates] = useState<TelegramUpdate[]>([]);
  const [updatesLoading, setUpdatesLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [webhookUrl] = useState(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/telegram-webhook`);
  const [realtimeConnected, setRealtimeConnected] = useState(false);

  const fetchRecentUpdates = async () => {
    try {
      console.log('🔄 Fetching recent updates for settings...');
      const { data, error } = await supabase
        .from('telegram_updates')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10);

      if (error) {
        console.error('❌ Error fetching updates:', error);
        throw error;
      }
      
      console.log('✅ Fetched recent updates:', data?.length || 0, 'items');
      setRecentUpdates(data || []);
    } catch (err) {
      console.error('❌ Error loading updates:', err);
    }
  };

  const handleRefreshUpdates = async () => {
    setRefreshing(true);
    await fetchRecentUpdates();
    setRefreshing(false);
  };

  useEffect(() => {
    const loadSettings = async () => {
      try {
        const { data, error } = await supabase
          .from('telegram_settings')
          .select('bot_token, is_active')
          .eq('user_id', user?.id)
          .maybeSingle();

        if (error) throw error;

        if (data) {
          setBotToken(data.bot_token);
          setIsActive(data.is_active);
          
          if (data.bot_token && data.is_active) {
            fetchBotInfo(data.bot_token);
          }
        }
      } catch (err) {
        console.error('Error loading settings:', err);
        setError('Failed to load settings. Please try again.');
      }
    };

    const loadRecentUpdates = async () => {
      setUpdatesLoading(true);
      await fetchRecentUpdates();
      setUpdatesLoading(false);
    };

    if (user?.id) {
      loadSettings();
    }
    
    loadRecentUpdates();

    // Subscribe to real-time updates using global subscription
    const unsubscribe = subscribeToTelegramUpdates((payload) => {
      console.log('🔥 Real-time update received in settings:', payload);
      setRealtimeConnected(true);
      
      if (payload.eventType === 'INSERT') {
        const newUpdate = payload.new as TelegramUpdate;
        setRecentUpdates(prev => {
          // Check if update already exists to prevent duplicates
          const exists = prev.some(update => update.id === newUpdate.id);
          if (exists) {
            console.log('⚠️ Duplicate update detected, skipping');
            return prev;
          }
          console.log('✅ Adding new update to settings');
          return [newUpdate, ...prev.slice(0, 9)]; // Keep only 10 most recent
        });
      } else if (payload.eventType === 'DELETE') {
        const deletedUpdate = payload.old as TelegramUpdate;
        console.log('🗑️ Removing deleted update from settings');
        setRecentUpdates(prev => prev.filter(update => update.id !== deletedUpdate.id));
      } else if (payload.eventType === 'UPDATE') {
        const updatedUpdate = payload.new as TelegramUpdate;
        console.log('📝 Updating existing update in settings');
        setRecentUpdates(prev => prev.map(update => 
          update.id === updatedUpdate.id ? updatedUpdate : update
        ));
      }
    });

    // Auto-refresh every 60 seconds as fallback
    const autoRefresh = setInterval(() => {
      if (!realtimeConnected) {
        console.log('🔄 Real-time not connected, auto-refreshing settings...');
        fetchRecentUpdates();
      }
    }, 60000);

    // Cleanup function
    return () => {
      console.log('🧹 Cleaning up Settings subscriptions...');
      unsubscribe();
      clearInterval(autoRefresh);
    };
  }, [user?.id]);

  const fetchBotInfo = async (token: string) => {
    try {
      const response = await fetch(`https://api.telegram.org/bot${token}/getMe`);
      const data = await response.json();
      
      if (data.ok) {
        setBotInfo({
          username: data.result.username,
          first_name: data.result.first_name
        });
      }
    } catch (err) {
      console.error('Error fetching bot info:', err);
    }
  };

  const setWebhook = async (token: string) => {
    try {
      const response = await fetch(`https://api.telegram.org/bot${token}/setWebhook`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          url: webhookUrl
        }),
      });
      
      const data = await response.json();
      console.log('Webhook set response:', data);
      
      if (!data.ok) {
        throw new Error(data.description || 'Failed to set webhook');
      }
      
      return data;
    } catch (err) {
      console.error('Error setting webhook:', err);
      throw err;
    }
  };

  const handleSave = async () => {
    if (!botToken.trim()) {
      setError('Bot token is required');
      return;
    }

    setIsSaving(true);
    setError(null);
    setSuccess(null);

    try {
      // Validate bot token
      const response = await fetch(`https://api.telegram.org/bot${botToken}/getMe`);
      const data = await response.json();
      
      if (!data.ok) {
        throw new Error('Invalid bot token');
      }

      // Set webhook if bot is active
      if (isActive) {
        await setWebhook(botToken);
      }

      // Save to database
      const { error } = await supabase
        .from('telegram_settings')
        .upsert(
          {
            user_id: user?.id,
            bot_token: botToken,
            webhook_url: webhookUrl,
            is_active: isActive
          },
          {
            onConflict: 'user_id'
          }
        );

      if (error) throw error;

      setBotInfo({
        username: data.result.username,
        first_name: data.result.first_name
      });
      
      setSuccess(`Settings saved successfully! ${isActive ? 'Webhook has been set up.' : ''}`);
    } catch (err) {
      console.error('Error saving settings:', err);
      setError(err instanceof Error ? err.message : 'Failed to save settings. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const copyWebhookUrl = () => {
    navigator.clipboard.writeText(webhookUrl);
    setSuccess('Webhook URL copied to clipboard!');
    setTimeout(() => setSuccess(null), 3000);
  };

  // Format date to "MMM DD, YYYY"
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  // Format time to "hh:mm AM/PM"
  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });
  };

  // Get badge variant based on update category
  const getBadgeVariant = (category: string): 'success' | 'warning' | 'error' => {
    switch (category) {
      case 'progress':
        return 'success';
      case 'issue':
        return 'error';
      case 'need':
        return 'warning';
      default:
        return 'success';
    }
  };

  // Get category label
  const getCategoryLabel = (category: string): string => {
    switch (category) {
      case 'progress':
        return 'Progress';
      case 'issue':
        return 'Issue';
      case 'need':
        return 'Need';
      default:
        return 'Update';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-white">Settings</h1>
      </div>
      
      <Card 
        title="Telegram Bot Integration" 
        icon={<Bot size={18} />}
        className="max-w-2xl"
      >
        <div className="space-y-6">
          {error && (
            <div className="bg-red-500/10 border border-red-500/50 rounded-md p-3 flex items-start">
              <AlertCircle size={18} className="text-red-500 mt-0.5 mr-2 flex-shrink-0" />
              <p className="text-red-500 text-sm">{error}</p>
            </div>
          )}

          {success && (
            <div className="bg-green-500/10 border border-green-500/50 rounded-md p-3">
              <p className="text-green-500 text-sm">{success}</p>
            </div>
          )}

          <div className="space-y-2">
            <label className="block text-sm font-medium text-white">
              Bot Token
            </label>
            <input
              type="password"
              value={botToken}
              onChange={(e) => setBotToken(e.target.value)}
              placeholder="Enter your Telegram bot token"
              className="w-full bg-gray-800 border border-gray-700 rounded-md py-2 px-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#FF5D2B]/50 focus:border-transparent"
            />
            <p className="text-xs text-gray-400">
              Get this token from @BotFather on Telegram
            </p>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-white">
              Webhook URL
            </label>
            <div className="flex items-center space-x-2">
              <input
                type="text"
                value={webhookUrl}
                readOnly
                className="flex-1 bg-gray-800 border border-gray-700 rounded-md py-2 px-3 text-gray-300 text-sm"
              />
              <button
                onClick={copyWebhookUrl}
                className="p-2 text-gray-400 hover:text-white transition-colors"
                title="Copy webhook URL"
              >
                <Copy size={16} />
              </button>
            </div>
            <p className="text-xs text-gray-400">
              This URL will receive messages from your Telegram bot
            </p>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-gray-800">
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="active"
                checked={isActive}
                onChange={(e) => setIsActive(e.target.checked)}
                className="rounded text-[#FF5D2B] focus:ring-[#FF5D2B]/50 bg-gray-700 border-gray-600"
              />
              <label htmlFor="active" className="text-sm text-white">
                Enable bot integration
              </label>
            </div>

            <Button
              variant="primary"
              size="sm"
              icon={<Save size={16} />}
              onClick={handleSave}
              disabled={isSaving}
            >
              {isSaving ? 'Saving...' : 'Save Settings'}
            </Button>
          </div>

          {isActive && botInfo && (
            <div className="mt-6 p-4 bg-gray-800 rounded-md">
              <h3 className="text-sm font-medium text-white mb-2">Bot Information</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Bot Name:</span>
                  <span className="text-white">{botInfo.first_name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Username:</span>
                  <span className="text-white">@{botInfo.username}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Status:</span>
                  <span className="text-green-400">Active</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Webhook:</span>
                  <span className="text-green-400">Configured</span>
                </div>
              </div>
              
              <div className="mt-4 p-3 bg-blue-500/10 border border-blue-500/50 rounded-md">
                <p className="text-blue-400 text-sm">
                  <strong>Setup Instructions:</strong>
                </p>
                <ol className="text-xs text-blue-300 mt-1 space-y-1">
                  <li>1. Send a message to @{botInfo.username} to start the bot</li>
                  <li>2. Engineers can now send updates directly to the bot</li>
                  <li>3. Messages will appear in real-time on your dashboard</li>
                </ol>
              </div>
            </div>
          )}
        </div>
      </Card>

      <Card
        title="Recent Telegram Updates"
        icon={<MessageSquare size={18} />}
        className="max-w-2xl"
        contentClassName="p-0"
        headerAction={
          <div className="flex items-center space-x-2">
            {realtimeConnected ? (
              <Wifi size={14} className="text-green-400" />
            ) : (
              <WifiOff size={14} className="text-red-400" />
            )}
            <button
              onClick={handleRefreshUpdates}
              disabled={refreshing}
              className="p-1 text-gray-400 hover:text-white transition-colors"
              title="Refresh updates"
            >
              <RefreshCw size={16} className={refreshing ? 'animate-spin' : ''} />
            </button>
          </div>
        }
      >
        <div className="divide-y divide-gray-700">
          {updatesLoading ? (
            <div className="p-4 text-center">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-[#FF5D2B] mx-auto"></div>
            </div>
          ) : recentUpdates.length === 0 ? (
            <div className="p-4 text-center text-gray-500">
              <MessageSquare size={48} className="mx-auto mb-2 opacity-50" />
              <p>No Telegram updates yet</p>
              <p className="text-xs mt-1">
                {isActive && botInfo ? 
                  `Send a message to @${botInfo.username} to test` : 
                  'Configure your bot above to start receiving updates'
                }
              </p>
              <button 
                onClick={handleRefreshUpdates}
                className="mt-2 text-sm text-[#FF5D2B] hover:text-[#FF7A50]"
              >
                Refresh
              </button>
            </div>
          ) : (
            recentUpdates.map((update) => (
              <div key={update.id} className="p-4 hover:bg-gray-800/50 transition-colors">
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0">
                    <div className="w-10 h-10 rounded-full overflow-hidden bg-[#FF5D2B]/20">
                      <div className="w-full h-full flex items-center justify-center text-[#FF5D2B]">
                        {update.from_name.charAt(0).toUpperCase()}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium text-white truncate">
                        {update.from_name}
                      </p>
                      <Badge variant={getBadgeVariant(update.category)}>
                        {getCategoryLabel(update.category)}
                      </Badge>
                    </div>
                    
                    <p className="mt-1 text-sm text-gray-300">
                      {update.content}
                    </p>
                    
                    <div className="mt-2 flex items-center text-xs text-gray-500">
                      <Clock size={12} className="mr-1" />
                      <span>{formatDate(update.created_at)}</span>
                      <span className="mx-1">•</span>
                      <span>{formatTime(update.created_at)}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </Card>
    </div>
  );
};

export default Settings;