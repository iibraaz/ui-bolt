import { createClient } from '@supabase/supabase-js';
import { Database } from '../types/supabase';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

console.log('🔧 Initializing Supabase client...');
console.log('Supabase URL:', supabaseUrl);
console.log('Supabase Key exists:', !!supabaseAnonKey);

// Validate that the URL is properly formatted
if (!supabaseUrl || !supabaseUrl.startsWith('https://') || !supabaseUrl.includes('.supabase.co')) {
  throw new Error('Invalid or missing Supabase URL. Please ensure VITE_SUPABASE_URL is set correctly in your .env file and points to a valid Supabase project URL.');
}

if (!supabaseAnonKey) {
  throw new Error('Missing Supabase anonymous key. Please ensure VITE_SUPABASE_ANON_KEY is set in your .env file.');
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
  realtime: {
    params: {
      eventsPerSecond: 50,
    },
  },
});

// Global real-time management
let globalChannel: any = null;
let subscribers: Set<(update: any) => void> = new Set();
let connectionStatus = false;
let reconnectAttempts = 0;
const maxReconnectAttempts = 5;

// Setup global real-time subscription
const setupGlobalRealtime = () => {
  if (globalChannel) {
    console.log('🔄 Removing existing global channel...');
    supabase.removeChannel(globalChannel);
    globalChannel = null;
  }

  console.log('🚀 Setting up new global real-time subscription...');
  
  globalChannel = supabase
    .channel('global-telegram-updates', {
      config: {
        broadcast: { self: false },
        presence: { key: 'global' },
        private: false
      }
    })
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'telegram_updates'
      },
      (payload) => {
        console.log('🔥 GLOBAL Real-time event received:', payload);
        connectionStatus = true;
        reconnectAttempts = 0;
        
        // Notify all subscribers
        subscribers.forEach(callback => {
          try {
            callback(payload);
          } catch (error) {
            console.error('❌ Error in subscriber callback:', error);
          }
        });
      }
    )
    .on('subscribe', (status, err) => {
      console.log('📡 Global subscription status:', status);
      if (status === 'SUBSCRIBED') {
        console.log('✅ Successfully subscribed to real-time updates');
        connectionStatus = true;
        reconnectAttempts = 0;
      } else if (status === 'CHANNEL_ERROR') {
        console.error('❌ Channel error:', err);
        connectionStatus = false;
        attemptReconnect();
      }
    })
    .on('error', (error) => {
      console.error('❌ Global subscription error:', error);
      connectionStatus = false;
      attemptReconnect();
    })
    .subscribe();

  return globalChannel;
};

// Attempt to reconnect with exponential backoff
const attemptReconnect = () => {
  if (reconnectAttempts >= maxReconnectAttempts) {
    console.error('❌ Max reconnection attempts reached');
    return;
  }

  reconnectAttempts++;
  const delay = Math.min(1000 * Math.pow(2, reconnectAttempts), 30000); // Max 30 seconds
  
  console.log(`🔄 Attempting reconnection ${reconnectAttempts}/${maxReconnectAttempts} in ${delay}ms...`);
  
  setTimeout(() => {
    setupGlobalRealtime();
  }, delay);
};

// Subscribe to global updates
export const subscribeToTelegramUpdates = (callback: (payload: any) => void) => {
  console.log('📝 Adding subscriber to global updates');
  subscribers.add(callback);
  
  // Setup global channel if not exists
  if (!globalChannel) {
    setupGlobalRealtime();
  }
  
  // Return unsubscribe function
  return () => {
    console.log('🗑️ Removing subscriber from global updates');
    subscribers.delete(callback);
    
    // If no more subscribers, clean up the channel
    if (subscribers.size === 0 && globalChannel) {
      console.log('🧹 No more subscribers, cleaning up global channel');
      supabase.removeChannel(globalChannel);
      globalChannel = null;
      connectionStatus = false;
    }
  };
};

// Get connection status
export const getRealtimeStatus = () => connectionStatus;

// Force reconnection
export const forceReconnect = () => {
  console.log('🔄 Forcing real-time reconnection...');
  reconnectAttempts = 0;
  setupGlobalRealtime();
};

// Initialize global real-time on module load
console.log('🎯 Initializing global real-time subscription...');
setupGlobalRealtime();

// Test the connection
supabase.from('telegram_updates').select('*').limit(1).then(({ data, error }) => {
  if (error) {
    console.error('❌ Supabase connection test failed:', error);
  } else {
    console.log('✅ Supabase connection test successful');
  }
});

// Monitor connection status
setInterval(() => {
  if (subscribers.size > 0) {
    console.log(`📊 Real-time status: ${connectionStatus ? 'Connected' : 'Disconnected'}, Subscribers: ${subscribers.size}`);
  }
}, 30000); // Log every 30 seconds if there are subscribers