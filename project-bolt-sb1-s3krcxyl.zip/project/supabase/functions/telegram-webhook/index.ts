import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'npm:@supabase/supabase-js@2.39.7';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface TelegramUpdate {
  message?: {
    message_id: number;
    from: {
      id: number;
      first_name: string;
      last_name?: string;
      username?: string;
    };
    chat: {
      id: number;
    };
    text?: string;
  };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    console.log('Telegram webhook received');
    
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const update: TelegramUpdate = await req.json();
    console.log('Received update:', JSON.stringify(update, null, 2));

    if (!update.message || !update.message.text) {
      console.log('No message or text found in update');
      return new Response(
        JSON.stringify({ success: true, message: 'No text message to process' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      );
    }

    const { message } = update;

    // Analyze message content to determine category
    const content = message.text.toLowerCase();
    let category = 'progress';

    if (content.includes('need') || content.includes('require') || content.includes('want') || content.includes('request')) {
      category = 'need';
    } else if (content.includes('issue') || content.includes('problem') || content.includes('bug') || content.includes('error') || content.includes('broken') || content.includes('fail')) {
      category = 'issue';
    } else if (content.includes('complete') || content.includes('done') || content.includes('finish') || content.includes('progress') || content.includes('update')) {
      category = 'progress';
    }

    const fromName = `${message.from.first_name}${message.from.last_name ? ' ' + message.from.last_name : ''}`;

    console.log('Inserting update into database...');
    
    // Store the update in Supabase
    const { data, error } = await supabaseClient
      .from('telegram_updates')
      .insert({
        message_id: message.message_id.toString(),
        chat_id: message.chat.id.toString(),
        from_id: message.from.id.toString(),
        from_name: fromName,
        content: message.text,
        category
      })
      .select();

    if (error) {
      console.error('Database error:', error);
      throw error;
    }

    console.log('Successfully inserted update:', data);

    return new Response(
      JSON.stringify({ success: true, data }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error) {
    console.error('Webhook error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});