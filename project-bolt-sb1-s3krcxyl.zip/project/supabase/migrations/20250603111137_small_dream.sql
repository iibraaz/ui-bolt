/*
  # Update telegram_settings user_id type
  
  1. Changes
    - Change user_id column type from UUID to TEXT
    - Update RLS policies to handle TEXT type
  
  2. Security
    - Temporarily disable RLS policies
    - Recreate policies with TEXT type casting
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can insert their own telegram settings" ON telegram_settings;
DROP POLICY IF EXISTS "Users can update their own telegram settings" ON telegram_settings;
DROP POLICY IF EXISTS "Users can view their own telegram settings" ON telegram_settings;

-- Drop constraints in correct order
ALTER TABLE telegram_settings DROP CONSTRAINT IF EXISTS telegram_settings_user_id_fkey;
ALTER TABLE telegram_settings DROP CONSTRAINT IF EXISTS telegram_settings_user_id_key;

-- Change column type
ALTER TABLE telegram_settings ALTER COLUMN user_id TYPE TEXT;

-- Add unique constraint back
ALTER TABLE telegram_settings ADD CONSTRAINT telegram_settings_user_id_key UNIQUE (user_id);

-- Recreate policies with TEXT type
CREATE POLICY "Users can insert their own telegram settings"
ON telegram_settings
FOR INSERT
TO authenticated
WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Users can update their own telegram settings"
ON telegram_settings
FOR UPDATE
TO authenticated
USING (auth.uid()::text = user_id);

CREATE POLICY "Users can view their own telegram settings"
ON telegram_settings
FOR SELECT
TO authenticated
USING (auth.uid()::text = user_id);