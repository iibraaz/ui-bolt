/*
  # Fix Telegram Updates Display
  
  1. Ensure proper table structure
  2. Fix RLS policies for proper access
  3. Add debugging data to test display
*/

-- Ensure the table exists with correct structure
CREATE TABLE IF NOT EXISTS telegram_updates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id text NOT NULL,
  chat_id text NOT NULL,
  from_id text NOT NULL,
  from_name text NOT NULL,
  content text NOT NULL,
  category text DEFAULT 'progress' CHECK (category IN ('progress', 'issue', 'need')),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE telegram_updates ENABLE ROW LEVEL SECURITY;

-- Drop existing policies
DROP POLICY IF EXISTS "Allow anonymous insert for telegram webhook" ON telegram_updates;
DROP POLICY IF EXISTS "Allow authenticated users to view all updates" ON telegram_updates;
DROP POLICY IF EXISTS "Allow anonymous users to view all updates" ON telegram_updates;

-- Create new policies
CREATE POLICY "Allow anonymous insert for telegram webhook"
  ON telegram_updates
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to view all updates"
  ON telegram_updates
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow anonymous users to view all updates"
  ON telegram_updates
  FOR SELECT
  TO anon
  USING (true);

-- Add indexes for better performance
DROP INDEX IF EXISTS idx_telegram_updates_created_at;
DROP INDEX IF EXISTS idx_telegram_updates_category;

CREATE INDEX idx_telegram_updates_created_at ON telegram_updates(created_at DESC);
CREATE INDEX idx_telegram_updates_category ON telegram_updates(category);

-- Clear any existing test data
DELETE FROM telegram_updates WHERE message_id LIKE 'test_%';

-- Add some test data to verify the UI is working
INSERT INTO telegram_updates (message_id, chat_id, from_id, from_name, content, category, created_at) VALUES
  ('debug_1', '123456789', '987654321', 'Test Engineer', 'This is a test message to verify the UI is working correctly. Foundation work completed.', 'progress', now() - interval '10 minutes'),
  ('debug_2', '123456789', '987654322', 'Debug User', 'Testing issue reporting functionality. Found a problem with the electrical system.', 'issue', now() - interval '20 minutes'),
  ('debug_3', '123456789', '987654323', 'Sample Worker', 'We need more materials for the next phase of construction.', 'need', now() - interval '30 minutes')
ON CONFLICT (id) DO NOTHING;