/*
  # Telegram Updates Table Setup
  
  1. New Tables
    - telegram_updates
      - id (uuid, primary key)
      - message_id (text)
      - chat_id (text)
      - from_id (text)
      - from_name (text)
      - content (text)
      - category (text with check constraint)
      - created_at (timestamptz)
      
  2. Security
    - Enable RLS
    - Add policies for insert and select
    
  3. Performance
    - Add indexes for category and created_at
*/

-- Create telegram_updates table if it doesn't exist
CREATE TABLE IF NOT EXISTS telegram_updates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id text NOT NULL,
  chat_id text NOT NULL,
  from_id text NOT NULL,
  from_name text NOT NULL,
  content text NOT NULL,
  category text CHECK (category IN ('progress', 'issue', 'need')),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS if not already enabled
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_tables 
    WHERE schemaname = 'public' 
    AND tablename = 'telegram_updates' 
    AND rowsecurity = true
  ) THEN
    ALTER TABLE telegram_updates ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

-- Create policies if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'telegram_updates' 
    AND policyname = 'Anyone can insert telegram updates'
  ) THEN
    CREATE POLICY "Anyone can insert telegram updates"
      ON telegram_updates
      FOR INSERT
      TO anon
      WITH CHECK (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'telegram_updates' 
    AND policyname = 'Users can view all telegram updates'
  ) THEN
    CREATE POLICY "Users can view all telegram updates"
      ON telegram_updates
      FOR SELECT
      TO authenticated
      USING (true);
  END IF;
END $$;

-- Add indexes if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE schemaname = 'public' 
    AND tablename = 'telegram_updates' 
    AND indexname = 'idx_telegram_updates_created_at'
  ) THEN
    CREATE INDEX idx_telegram_updates_created_at 
      ON telegram_updates(created_at DESC);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE schemaname = 'public' 
    AND tablename = 'telegram_updates' 
    AND indexname = 'idx_telegram_updates_category'
  ) THEN
    CREATE INDEX idx_telegram_updates_category 
      ON telegram_updates(category);
  END IF;
END $$;