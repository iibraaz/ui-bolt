/*
  # Fix Real-time Connection Issues
  
  1. Database Changes
    - Ensure proper RLS policies for real-time
    - Add DELETE policy for authenticated users
    - Verify table structure
    
  2. Real-time Configuration
    - Enable real-time for telegram_updates table
    - Configure proper permissions
*/

-- Ensure the table exists with correct structure
CREATE TABLE IF NOT EXISTS telegram_updates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id text NOT NULL,
  chat_id text NOT NULL,
  from_id text NOT NULL,
  from_name text NOT NULL,
  content text NOT NULL,
  category text DEFAULT 'progress' CHECK (category IN ('progress', 'issue', 'need')),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE telegram_updates ENABLE ROW LEVEL SECURITY;

-- Drop all existing policies
DROP POLICY IF EXISTS "Allow anonymous insert for telegram webhook" ON telegram_updates;
DROP POLICY IF EXISTS "Allow authenticated users to view all updates" ON telegram_updates;
DROP POLICY IF EXISTS "Allow anonymous users to view all updates" ON telegram_updates;
DROP POLICY IF EXISTS "Allow authenticated users to delete updates" ON telegram_updates;

-- Create comprehensive policies for real-time to work properly
CREATE POLICY "Allow anonymous insert for telegram webhook"
  ON telegram_updates
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to view all updates"
  ON telegram_updates
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow anonymous users to view all updates"
  ON telegram_updates
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Allow authenticated users to delete updates"
  ON telegram_updates
  FOR DELETE
  TO authenticated
  USING (true);

CREATE POLICY "Allow authenticated users to update updates"
  ON telegram_updates
  FOR UPDATE
  TO authenticated
  USING (true);

-- Ensure indexes exist
DROP INDEX IF EXISTS idx_telegram_updates_created_at;
DROP INDEX IF EXISTS idx_telegram_updates_category;

CREATE INDEX idx_telegram_updates_created_at ON telegram_updates(created_at DESC);
CREATE INDEX idx_telegram_updates_category ON telegram_updates(category);

-- Enable real-time for this table (this is crucial)
ALTER PUBLICATION supabase_realtime ADD TABLE telegram_updates;

-- Clear test data and add fresh test data
DELETE FROM telegram_updates;

INSERT INTO telegram_updates (message_id, chat_id, from_id, from_name, content, category, created_at) VALUES
  ('live_1', '123456789', '987654321', 'John Engineer', 'Foundation work completed successfully. Ready for next phase.', 'progress', now() - interval '5 minutes'),
  ('live_2', '123456789', '987654322', 'Sarah Builder', 'Electrical wiring issue in section B needs immediate attention.', 'issue', now() - interval '10 minutes'),
  ('live_3', '123456789', '987654323', 'Mike Constructor', 'Need additional steel beams for second floor construction.', 'need', now() - interval '15 minutes');