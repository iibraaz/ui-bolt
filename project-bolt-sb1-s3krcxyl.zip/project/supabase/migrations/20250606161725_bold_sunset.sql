/*
  # Fix Telegram Updates Table and Policies
  
  1. Ensure telegram_updates table exists with correct structure
  2. Set up proper RLS policies
  3. Add indexes for performance
  4. Insert test data to verify functionality
*/

-- Drop existing policies to recreate them properly
DROP POLICY IF EXISTS "Anyone can insert telegram updates" ON telegram_updates;
DROP POLICY IF EXISTS "Users can view all telegram updates" ON telegram_updates;

-- Ensure the table exists with correct structure
CREATE TABLE IF NOT EXISTS telegram_updates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id text NOT NULL,
  chat_id text NOT NULL,
  from_id text NOT NULL,
  from_name text NOT NULL,
  content text NOT NULL,
  category text DEFAULT 'progress' CHECK (category IN ('progress', 'issue', 'need')),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE telegram_updates ENABLE ROW LEVEL SECURITY;

-- Create policies that allow both anonymous and authenticated access
CREATE POLICY "Allow anonymous insert for telegram webhook"
  ON telegram_updates
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to view all updates"
  ON telegram_updates
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow anonymous users to view all updates"
  ON telegram_updates
  FOR SELECT
  TO anon
  USING (true);

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_telegram_updates_created_at ON telegram_updates(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_telegram_updates_category ON telegram_updates(category);

-- Insert some test data to verify the UI is working
INSERT INTO telegram_updates (message_id, chat_id, from_id, from_name, content, category, created_at) VALUES
  ('test_1', '123456789', '987654321', 'John Engineer', 'Completed the foundation work for building A. All concrete has been poured and is curing properly.', 'progress', now() - interval '1 hour'),
  ('test_2', '123456789', '987654322', 'Sarah Builder', 'We have an issue with the electrical wiring in section B. Need to consult with the electrical engineer.', 'issue', now() - interval '2 hours'),
  ('test_3', '123456789', '987654323', 'Mike Constructor', 'Need additional steel beams for the second floor. Current supply is insufficient.', 'need', now() - interval '3 hours'),
  ('test_4', '123456789', '987654324', 'Lisa Foreman', 'Roofing installation is 75% complete. Weather conditions are favorable for the next few days.', 'progress', now() - interval '4 hours'),
  ('test_5', '123456789', '987654325', 'Tom Supervisor', 'Safety inspection passed with flying colors. All workers are following protocols correctly.', 'progress', now() - interval '5 hours')
ON CONFLICT (id) DO NOTHING;