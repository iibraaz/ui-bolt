-- Add missing RLS policies for telegram_updates
DROP POLICY IF EXISTS "Users can view all telegram updates" ON telegram_updates;
DROP POLICY IF EXISTS "Anyone can insert telegram updates" ON telegram_updates;

-- Allow all authenticated users to view updates
CREATE POLICY "Users can view all telegram updates"
ON telegram_updates
FOR SELECT
TO authenticated
USING (true);

-- Allow the webhook to insert updates
CREATE POLICY "Anyone can insert telegram updates"
ON telegram_updates
FOR INSERT
TO anon
WITH CHECK (true);

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_telegram_updates_created_at ON telegram_updates(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_telegram_updates_category ON telegram_updates(category);