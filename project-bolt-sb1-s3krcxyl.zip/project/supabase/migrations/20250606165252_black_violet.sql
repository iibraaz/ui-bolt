/*
  # Fix Delete Permissions for Telegram Updates
  
  1. Security Updates
    - Add DELETE policy for authenticated users
    - Add UPDATE policy for authenticated users
    - Ensure real-time is properly configured
    
  2. Verification
    - Test that authenticated users can delete messages
    - Ensure real-time updates work for all operations
*/

-- Ensure the table exists with correct structure
CREATE TABLE IF NOT EXISTS telegram_updates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id text NOT NULL,
  chat_id text NOT NULL,
  from_id text NOT NULL,
  from_name text NOT NULL,
  content text NOT NULL,
  category text DEFAULT 'progress' CHECK (category IN ('progress', 'issue', 'need')),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE telegram_updates ENABLE ROW LEVEL SECURITY;

-- Drop all existing policies to recreate them properly
DROP POLICY IF EXISTS "Allow anonymous insert for telegram webhook" ON telegram_updates;
DROP POLICY IF EXISTS "Allow authenticated users to view all updates" ON telegram_updates;
DROP POLICY IF EXISTS "Allow anonymous users to view all updates" ON telegram_updates;
DROP POLICY IF EXISTS "Allow authenticated users to delete updates" ON telegram_updates;
DROP POLICY IF EXISTS "Allow authenticated users to update updates" ON telegram_updates;

-- Create comprehensive policies
CREATE POLICY "Allow anonymous insert for telegram webhook"
  ON telegram_updates
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to view all updates"
  ON telegram_updates
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow anonymous users to view all updates"
  ON telegram_updates
  FOR SELECT
  TO anon
  USING (true);

-- CRITICAL: Add DELETE policy for authenticated users
CREATE POLICY "Allow authenticated users to delete updates"
  ON telegram_updates
  FOR DELETE
  TO authenticated
  USING (true);

-- Add UPDATE policy for authenticated users
CREATE POLICY "Allow authenticated users to update updates"
  ON telegram_updates
  FOR UPDATE
  TO authenticated
  USING (true);

-- Ensure indexes exist for performance
DROP INDEX IF EXISTS idx_telegram_updates_created_at;
DROP INDEX IF EXISTS idx_telegram_updates_category;

CREATE INDEX idx_telegram_updates_created_at ON telegram_updates(created_at DESC);
CREATE INDEX idx_telegram_updates_category ON telegram_updates(category);

-- Enable real-time for this table (crucial for live updates)
DO $$
BEGIN
  -- Check if table is already in the publication
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' 
    AND tablename = 'telegram_updates'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE telegram_updates;
  END IF;
EXCEPTION
  WHEN others THEN
    -- If there's an error, try to add it anyway
    ALTER PUBLICATION supabase_realtime ADD TABLE telegram_updates;
END $$;

-- Clean up any remaining test data
DELETE FROM telegram_updates WHERE 
  message_id LIKE 'test_%' OR 
  message_id LIKE 'debug_%' OR 
  message_id LIKE 'live_%' OR
  from_name IN ('Test Engineer', 'Debug User', 'Sample Worker', 'John Engineer', 'Sarah Builder', 'Mike Constructor');