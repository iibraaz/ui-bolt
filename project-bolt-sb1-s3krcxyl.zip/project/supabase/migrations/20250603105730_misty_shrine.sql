/*
  # Add Telegram Bot Integration Tables

  1. New Tables
    - `telegram_settings`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `bot_token` (text, encrypted)
      - `webhook_url` (text)
      - `is_active` (boolean)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `telegram_updates`
      - `id` (uuid, primary key)
      - `message_id` (text)
      - `chat_id` (text)
      - `from_id` (text)
      - `from_name` (text)
      - `content` (text)
      - `category` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users
*/

-- Create telegram_settings table
CREATE TABLE IF NOT EXISTS telegram_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  bot_token text NOT NULL,
  webhook_url text,
  is_active boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE (user_id)
);

-- Create telegram_updates table
CREATE TABLE IF NOT EXISTS telegram_updates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id text NOT NULL,
  chat_id text NOT NULL,
  from_id text NOT NULL,
  from_name text NOT NULL,
  content text NOT NULL,
  category text CHECK (category IN ('progress', 'issue', 'need')),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE telegram_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE telegram_updates ENABLE ROW LEVEL SECURITY;

-- Create policies for telegram_settings
CREATE POLICY "Users can view their own telegram settings"
  ON telegram_settings
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own telegram settings"
  ON telegram_settings
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own telegram settings"
  ON telegram_settings
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create policies for telegram_updates
CREATE POLICY "Users can view all telegram updates"
  ON telegram_updates
  FOR SELECT
  TO authenticated
  USING (true);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for updated_at
CREATE TRIGGER update_telegram_settings_updated_at
  BEFORE UPDATE ON telegram_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();