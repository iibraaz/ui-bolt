/*
  # Remove fake/test messages and ensure proper delete functionality
  
  1. Changes
    - Remove all test/fake messages from telegram_updates table
    - Ensure DELETE policy exists for authenticated users
    - Keep real-time publication enabled
  
  2. Security
    - Maintain all existing RLS policies
    - Ensure users can delete messages they select
*/

-- Remove all test/fake messages
DELETE FROM telegram_updates WHERE 
  message_id LIKE 'test_%' OR 
  message_id LIKE 'debug_%' OR 
  message_id LIKE 'live_%' OR
  from_name IN ('Test Engineer', 'Debug User', 'Sample Worker', 'John Engineer', 'Sarah Builder', 'Mike Constructor');

-- Ensure DELETE policy exists (should already exist from previous migration)
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'telegram_updates' 
    AND policyname = 'Allow authenticated users to delete updates'
  ) THEN
    CREATE POLICY "Allow authenticated users to delete updates"
      ON telegram_updates
      FOR DELETE
      TO authenticated
      USING (true);
  END IF;
END $$;

-- Ensure UPDATE policy exists (should already exist from previous migration)
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'telegram_updates' 
    AND policyname = 'Allow authenticated users to update updates'
  ) THEN
    CREATE POLICY "Allow authenticated users to update updates"
      ON telegram_updates
      FOR UPDATE
      TO authenticated
      USING (true);
  END IF;
END $$;

-- Verify real-time is enabled (should already be enabled from previous migration)
DO $$
BEGIN
  -- Check if table is already in the publication
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' 
    AND tablename = 'telegram_updates'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE telegram_updates;
  END IF;
END $$;