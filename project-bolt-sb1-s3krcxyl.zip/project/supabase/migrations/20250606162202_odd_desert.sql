-- Ensure the telegram_updates table has the correct structure and policies
DROP TABLE IF EXISTS telegram_updates CASCADE;

CREATE TABLE telegram_updates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id text NOT NULL,
  chat_id text NOT NULL,
  from_id text NOT NULL,
  from_name text NOT NULL,
  content text NOT NULL,
  category text DEFAULT 'progress' CHECK (category IN ('progress', 'issue', 'need')),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE telegram_updates ENABLE ROW LEVEL SECURITY;

-- Create policies that allow webhook to insert and users to read
CREATE POLICY "Allow anonymous insert for telegram webhook"
  ON telegram_updates
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to view all updates"
  ON telegram_updates
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow anonymous users to view all updates"
  ON telegram_updates
  FOR SELECT
  TO anon
  USING (true);

-- Add indexes for better performance
CREATE INDEX idx_telegram_updates_created_at ON telegram_updates(created_at DESC);
CREATE INDEX idx_telegram_updates_category ON telegram_updates(category);

-- Remove any test data
DELETE FROM telegram_updates WHERE message_id LIKE 'test_%';